import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import CheckMate 1.0 // Sesuai URI qmlRegisterType Anda di main.cpp

Rectangle {
    id: compareResultRoot
    anchors.fill: parent
    color: "#f5f5f5"

    property var rawParams: []
    property var vfmParams: []
    property var products: []

    // 1. INSTANSIASI C++ BACKEND
    CompareBackend {
        id: compareLogic
    }

    // 2. FUNGSI PICU KALKULASI C++
    function refreshDataAndCalculate() {
        if (typeof FileIO !== "undefined") {
            products = FileIO.readProducts();
        } else {
            console.warn("FileIO tidak ditemukan.");
            products = [];
        }
        // Kirim data ke fungsi C++ (lebar tabel dikurangi padding 80px)
        var targetWidth = compareResultRoot.width > 80 ? compareResultRoot.width - 80 : 0;
        compareLogic.calculate(products, rawParams, vfmParams, targetWidth);
    }

    onRawParamsChanged: Qt.callLater(refreshDataAndCalculate)
    onVfmParamsChanged: Qt.callLater(refreshDataAndCalculate)

    // Picu ulang jika resolusi layar di-resize
    onWidthChanged: {
        if (visible && products.length > 0) {
            Qt.callLater(refreshDataAndCalculate)
        }
    }

    onVisibleChanged: {
        if (visible) {
            Qt.callLater(refreshDataAndCalculate)
        }
    }

    Component.onCompleted: {
        Qt.callLater(refreshDataAndCalculate);
    }

    ScrollView {
        anchors.fill: parent
        contentWidth: width
        contentHeight: mainColumn.height + 60
        clip: true
        ScrollBar.vertical.policy: ScrollBar.AsNeeded
        ScrollBar.horizontal.policy: ScrollBar.AlwaysOff

        Column {
            id: mainColumn
            width: parent.width
            spacing: 25
            padding: 20

            // ==========================================
            // TOMBOL BACK KE DASHBOARD
            // ==========================================
            Rectangle {
                width: 170
                height: 35
                radius: 5
                color: backBtnArea.pressed ? "#e6e6e6" : "#ffffff"
                border.color: "#cccccc"
                border.width: 1

                Row {
                    anchors.centerIn: parent
                    spacing: 10
                    Text {
                        text: "←"
                        font.pixelSize: 16
                        font.weight: Font.Bold
                        color: "#000000"
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Text {
                        text: "Back to Dashboard"
                        font.family: "Inknut Antiqua"
                        font.pixelSize: 11
                        color: "#000000"
                        anchors.verticalCenter: parent.verticalCenter
                    }
                }

                MouseArea {
                    id: backBtnArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        if (typeof root !== "undefined") {
                            root.navigateTo("dashboard");
                        }
                    }
                }
            }

            // ==========================================
            // 1. PRODUCT CARDS AREA
            // ==========================================
            ScrollView {
                width: parent.width - 40
                height: 380
                contentWidth: rowCards.width
                clip: true
                ScrollBar.horizontal.policy: ScrollBar.AsNeeded
                ScrollBar.vertical.policy: ScrollBar.AlwaysOff

                Row {
                    id: rowCards
                    spacing: 25

                    Repeater {
                        model: products
                        delegate: Rectangle {
                            property int paramCount: modelData.parameters ? (modelData.parameters.count !== undefined ? modelData.parameters.count : modelData.parameters.length) : 0

                            width: 800
                            height: 248 + (paramCount * 65) + 30
                            border.color: "#cccccc"
                            border.width: 1
                            radius: 10
                            color: "#ffffff"

                            Rectangle {
                                x: 20; y: 41; width: 240; height: 192
                                border.color: "#cccccc"; radius: 5; color: "#f5f5f5"
                                Image {
                                    anchors.fill: parent; anchors.margins: 4
                                    source: (modelData.image && modelData.image.toString().indexOf("PicPlaceholder") === -1)
                                            ? modelData.image : "assets/PicPlaceholder.png"
                                    fillMode: Image.PreserveAspectFit
                                }
                            }

                            Item {
                                x: 313; y: 41; width: 467; height: 50
                                Text { y: 0; text: "Name"; font.pixelSize: 9; font.family: "Inknut Antiqua"; color: "#000000" }
                                Rectangle {
                                    y: 23; width: 467; height: 27
                                    border.color: "#cccccc"; radius: 5; color: "#f5f5f5"
                                    Text { anchors.fill: parent; anchors.leftMargin: 10; verticalAlignment: Text.AlignVCenter; text: modelData.name; font.pixelSize: 11; font.family: "Inknut Antiqua"; color: "#000000"; clip: true }
                                }
                            }

                            Item {
                                x: 313; y: 99; width: 233; height: 50
                                Text { y: 0; text: "Price"; font.pixelSize: 9; font.family: "Inknut Antiqua"; color: "#000000" }
                                Rectangle {
                                    y: 23; width: 233; height: 27
                                    border.color: "#cccccc"; radius: 5; color: "#f5f5f5"
                                    Text { anchors.fill: parent; anchors.leftMargin: 10; verticalAlignment: Text.AlignVCenter; text: modelData.price; font.pixelSize: 11; font.family: "Inknut Antiqua"; color: "#000000"; clip: true }
                                }
                            }

                            Item {
                                x: 566; y: 99; width: 214; height: 50
                                Text { y: 0; text: "Currency"; font.pixelSize: 9; font.family: "Inknut Antiqua"; color: "#000000" }
                                Rectangle {
                                    y: 23; width: 214; height: 27
                                    border.color: "#cccccc"; radius: 5; color: "#f5f5f5"
                                    Text { anchors.fill: parent; anchors.leftMargin: 10; verticalAlignment: Text.AlignVCenter; text: modelData.currency; font.pixelSize: 11; font.family: "Inknut Antiqua"; color: "#000000"; clip: true }
                                }
                            }

                            Item {
                                x: 313; y: 157; width: 467; height: 76
                                Text { y: 0; text: "Description"; font.pixelSize: 9; font.family: "Inknut Antiqua"; color: "#000000" }
                                Rectangle {
                                    y: 23; width: 467; height: 53
                                    border.color: "#cccccc"; radius: 5; color: "#f5f5f5"
                                    Text { anchors.fill: parent; anchors.margins: 10; text: modelData.description; font.pixelSize: 11; font.family: "Inknut Antiqua"; color: "#000000"; wrapMode: Text.Wrap; clip: true }
                                }
                            }

                            Column {
                                x: 20; y: 248; spacing: 15
                                Repeater {
                                    model: modelData.parameters || []
                                    delegate: Item {
                                        width: 760; height: 50

                                        Text { x: 0; y: 0; text: modelData.paramName !== undefined ? modelData.paramName : (model.paramName || ""); font.pixelSize: 9; font.family: "Inknut Antiqua"; color: "#000000" }
                                        Rectangle {
                                            x: 0; y: 23; width: 527; height: 27
                                            border.color: "#cccccc"; radius: 5; color: "#f5f5f5"
                                            Text { anchors.fill: parent; anchors.leftMargin: 10; verticalAlignment: Text.AlignVCenter; text: modelData.value !== undefined ? modelData.value : (model.value || ""); font.pixelSize: 11; font.family: "Inknut Antiqua"; color: "#000000"; clip: true }
                                        }

                                        Text { x: 546; y: 0; text: "Unit"; font.pixelSize: 9; font.family: "Inknut Antiqua"; color: "#000000" }
                                        Rectangle {
                                            x: 546; y: 23; width: 214; height: 27
                                            border.color: "#cccccc"; radius: 5; color: "#f5f5f5"
                                            Text { anchors.fill: parent; anchors.leftMargin: 10; verticalAlignment: Text.AlignVCenter; text: modelData.unit !== undefined ? modelData.unit : (model.unit || ""); font.pixelSize: 11; font.family: "Inknut Antiqua"; color: "#000000"; clip: true }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // 2. TABLE SUMMARY AREA (Binding to C++)
            // ==========================================
            Rectangle {
                width: parent.width - 40
                height: summaryContainer.implicitHeight + 50
                border.color: "#cccccc"
                border.width: 1
                color: "#fdfdfd"
                radius: 10

                Column {
                    id: summaryContainer
                    width: parent.width - 40
                    anchors.top: parent.top
                    anchors.topMargin: 25
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 25

                    Text {
                        text: "Summary"
                        font.family: "Inknut Antiqua"
                        font.pixelSize: 18
                        font.weight: Font.Bold
                        anchors.horizontalCenter: parent.horizontalCenter
                        color: "#000000"
                    }

                    ScrollView {
                        width: parent.width
                        height: tableCol.height
                        contentWidth: compareLogic.totalTableWidth
                        clip: true
                        ScrollBar.horizontal.policy: ScrollBar.AsNeeded
                        ScrollBar.vertical.policy: ScrollBar.AlwaysOff

                        Column {
                            id: tableCol
                            width: compareLogic.totalTableWidth
                            spacing: 0

                            // HEADER TABEL
                            Row {
                                width: parent.width
                                Repeater {
                                    model: compareLogic.tableHeaders
                                    delegate: Rectangle {
                                        width: compareLogic.columnWidths[index]
                                        height: 45
                                        color: "#fcf8e3"
                                        border.color: "#e6e6e6"
                                        border.width: 1

                                        Text {
                                            anchors.fill: parent
                                            anchors.margins: 10
                                            text: modelData
                                            font.family: "Inknut Antiqua"
                                            font.pixelSize: 11
                                            font.weight: Font.Bold
                                            verticalAlignment: Text.AlignVCenter
                                            horizontalAlignment: Text.AlignHCenter
                                            color: "#000000"
                                            wrapMode: Text.Wrap
                                        }
                                    }
                                }
                            }

                            // ISI BARIS TABEL
                            Repeater {
                                model: compareLogic.tableRows
                                delegate: Row {
                                    property var rowArray: modelData
                                    property int rIndex: index
                                    width: parent.width

                                    Repeater {
                                        model: rowArray
                                        delegate: Rectangle {
                                            width: compareLogic.columnWidths[index]
                                            height: 50
                                            color: rIndex % 2 === 0 ? "#ffffff" : "#fbfbfb"
                                            border.color: "#e6e6e6"
                                            border.width: 1

                                            Text {
                                                anchors.fill: parent
                                                anchors.margins: 10
                                                text: modelData
                                                font.family: "Inknut Antiqua"
                                                font.pixelSize: 11
                                                verticalAlignment: Text.AlignVCenter
                                                horizontalAlignment: Text.AlignHCenter
                                                color: "#000000"
                                                wrapMode: Text.Wrap
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // HASIL KOMPARASI
                    Row {
                        spacing: 20
                        anchors.left: parent.left

                        Rectangle {
                            width: lblPrice.implicitWidth + 24; height: 35
                            color: "#eff6ed"; border.color: "#d0e0d0"; border.width: 1; radius: 5
                            Text { id: lblPrice; anchors.centerIn: parent; text: "Best Price: " + compareLogic.bestPriceText; font.family: "Inknut Antiqua"; font.pixelSize: 11; color: "#000000" }
                        }
                        Rectangle {
                            width: lblVal.implicitWidth + 24; height: 35
                            color: "#eff6ed"; border.color: "#d0e0d0"; border.width: 1; radius: 5
                            Text { id: lblVal; anchors.centerIn: parent; text: "Best Value: " + compareLogic.bestValueText; font.family: "Inknut Antiqua"; font.pixelSize: 11; color: "#000000" }
                        }
                        Rectangle {
                            width: lblProd.implicitWidth + 24; height: 35
                            color: "#eff6ed"; border.color: "#d0e0d0"; border.width: 1; radius: 5
                            Text { id: lblProd; anchors.centerIn: parent; text: "Best Product: " + compareLogic.bestProductText; font.family: "Inknut Antiqua"; font.pixelSize: 11; font.weight: Font.Bold; color: "#000000" }
                        }
                    }
                }
            }
        }
    }
}