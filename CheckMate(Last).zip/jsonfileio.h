#ifndef JSONFILEIO_H
#define JSONFILEIO_H

#include <QObject>
#include <QVariantMap>

class JsonFileIO : public QObject
{
    Q_OBJECT
public:
    explicit JsonFileIO(QObject *parent = nullptr);

    Q_INVOKABLE void saveProduct(const QVariantMap &productData);
    Q_INVOKABLE QVariantList readProducts();
    Q_INVOKABLE void removeProduct(int index);
    Q_INVOKABLE void clearAllProducts();
};

#endif