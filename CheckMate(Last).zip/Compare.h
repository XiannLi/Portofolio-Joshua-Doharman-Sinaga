#ifndef COMPARE_H
#define COMPARE_H

#include <QObject>
#include <QVariantList>
#include <QVariantMap>
#include <QString>

class Compare : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString bestPriceText READ bestPriceText NOTIFY calculationDone)
    Q_PROPERTY(QString bestValueText READ bestValueText NOTIFY calculationDone)
    Q_PROPERTY(QString bestProductText READ bestProductText NOTIFY calculationDone)
    Q_PROPERTY(QVariantList tableHeaders READ tableHeaders NOTIFY calculationDone)
    Q_PROPERTY(QVariantList tableRows READ tableRows NOTIFY calculationDone)
    Q_PROPERTY(QVariantList columnWidths READ columnWidths NOTIFY calculationDone)
    Q_PROPERTY(double totalTableWidth READ totalTableWidth NOTIFY calculationDone)

public:
    explicit Compare(QObject *parent = nullptr);

    Q_INVOKABLE void calculate(const QVariantList& products,
                               const QVariantList& rawParams,
                               const QVariantList& vfmParams,
                               double availableWidth);

    QString bestPriceText() const;
    QString bestValueText() const;
    QString bestProductText() const;
    QVariantList tableHeaders() const;
    QVariantList tableRows() const;
    QVariantList columnWidths() const;
    double totalTableWidth() const;

signals:
    void calculationDone();

private:
    QString m_bestPriceText;
    QString m_bestValueText;
    QString m_bestProductText;
    QVariantList m_tableHeaders;
    QVariantList m_tableRows;
    QVariantList m_columnWidths;
    double m_totalTableWidth;

    struct ScoreData {
        int index;
        QString name;
        int totalScore = 0;
        int vfmScore = 0;
    };
};

#endif