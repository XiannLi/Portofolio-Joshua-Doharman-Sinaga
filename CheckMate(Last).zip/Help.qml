import QtQuick
import QtQuick.Controls
import CheckMate

Rectangle {
    id: helpRoot
    anchors.fill: parent
    color: "#fff9f0"

    property int selectedIndex: -1

    ListModel {
        id: faqModel

        ListElement {
            question: "Apa itu CheckMate?"
            answer: "CheckMate adalah aplikasi perbandingan produk yang membantu pengguna menentukan produk terbaik berdasarkan harga, nilai tambah (value for money), dan performa keseluruhan."
        }

        ListElement {
            question: "Bagaimana cara menambahkan produk baru?"
            answer: "Buka halaman Produk lalu klik Tambah Produk. Isi nama produk, harga, dan nilai parameter sebelum menyimpannya."
        }

        ListElement {
            question: "Bagaimana cara mengedit produk?"
            answer: "Buka halaman Produk, pilih produk, lalu klik Edit. Perbarui informasi dan simpan perubahan Anda."
        }

        ListElement {
            question: "Bagaimana cara menghapus produk?"
            answer: "Pilih produk dari halaman Produk lalu klik Hapus. Produk akan dihapus secara permanen."
        }

        ListElement {
            question: "Bagaimana cara membuat perbandingan?"
            answer: "Buka halaman Bandingkan, pilih produk dan parameter yang ingin Anda evaluasi, lalu mulai perbandingan."
        }

        ListElement {
            question: "Apa itu Parameter?"
            answer: "Parameter adalah atribut terukur yang digunakan untuk membandingkan produk, seperti daya tahan baterai, penyimpanan, berat, kecepatan, atau skor performa."
        }

        ListElement {
            question: "Bagaimana cara kerja penilaian perbandingannya?"
            answer: "CheckMate mengevaluasi produk menggunakan kategori Harga Terbaik, Nilai Terbaik, dan Produk Terbaik. Metode pemeringkatan Borda Count memberikan poin berdasarkan posisi peringkat."
        }

        ListElement {
            question: "Apa itu metode Borda Count?"
            answer: "Borda Count memberikan poin berdasarkan posisi peringkat. Produk dengan peringkat lebih tinggi akan menerima lebih banyak poin dan produk dengan total skor tertinggi menjadi pemenangnya."
        }

        ListElement {
            question: "Apa itu Harga Terbaik (Best Price)?"
            answer: "Harga Terbaik mengidentifikasi produk dengan harga paling menguntungkan sesuai dengan kriteria perbandingan yang dipilih."
        }

        ListElement {
            question: "Apa itu Nilai Terbaik (Best Value)?"
            answer: "Nilai Terbaik mengidentifikasi produk yang menawarkan keseimbangan paling baik antara harga dan performa."
        }

        ListElement {
            question: "Apa itu Produk Terbaik (Best Product)?"
            answer: "Produk Terbaik adalah pemenang keseluruhan setelah menggabungkan semua skor dari parameter dan kategori evaluasi yang dipilih."
        }

        ListElement {
            question: "Apa yang dimaksud dengan Value for Money (VFM)?"
            answer: "Value for Money mengukur efisiensi biaya dengan membandingkan harga produk terhadap nilai parameter."
        }

        ListElement {
            question: "Apa maksud preferensi Tertinggi (Highest)?"
            answer: "Tertinggi berarti nilai yang lebih besar dianggap lebih baik, seperti daya tahan baterai, kapasitas penyimpanan, atau performa."
        }

        ListElement {
            question: "Apa maksud preferensi Terendah (Lowest)?"
            answer: "Terendah berarti nilai yang lebih kecil dianggap lebih baik, seperti harga, berat, atau konsumsi daya."
        }

        ListElement {
            question: "Mengapa produk saya mendapat skor 0?"
            answer: "Produk dengan nilai yang kosong untuk parameter yang dipilih tidak dapat mengikuti evaluasi tersebut sehingga menerima 0 poin."
        }

        ListElement {
            question: "Mengapa produk saya dikecualikan dari peringkat?"
            answer: "Produk dapat dikecualikan apabila informasi yang diperlukan tidak lengkap, tidak valid, atau tidak tersedia."
        }

        ListElement {
            question: "Mengapa hasil saya berbeda dari perkiraan?"
            answer: "Periksa kembali semua nilai parameter, harga, dan pengaturan preferensi. Data yang tidak akurat dapat memengaruhi peringkat."
        }

        ListElement {
            question: "Bisakah saya membandingkan produk dengan spesifikasi yang berbeda?"
            answer: "Bisa, tetapi perbandingan akan lebih optimal bila produk memiliki tujuan yang mirip dan memiliki parameter yang sama."
        }

        ListElement {
            question: "Berapa banyak produk yang bisa saya bandingkan?"
            answer: "CheckMate mendukung perbandingan banyak produk sekaligus dalam satu kali perbandingan."
        }

        ListElement {
            question: "Bisakah saya menggunakan parameter khusus?"
            answer: "Ya. Anda dapat membuat parameter yang sesuai dengan kebutuhan perbandingan Anda."
        }

        ListElement {
            question: "Bagaimana cara mendapatkan hasil perbandingan yang lebih akurat?"
            answer: "Berikan informasi produk yang lengkap, gunakan parameter yang relevan, dan pilih pengaturan preferensi yang tepat."
        }

        ListElement {
            question: "Apa yang terjadi jika dua produk memiliki skor yang sama?"
            answer: "Produk dengan skor identik dianggap seri. Parameter tambahan dapat membantu memecahkan hasil seri tersebut."
        }

        ListElement {
            question: "Bisakah saya membandingkan produk dari merek yang berbeda?"
            answer: "Ya. CheckMate dapat membandingkan produk dari merek apa pun selama data perbandingannya tersedia."
        }

        ListElement {
            question: "Apa yang harus saya lakukan sebelum memulai perbandingan?"
            answer: "Pastikan semua informasi produk sudah lengkap dan semua preferensi parameter telah dikonfigurasi dengan benar."
        }

        ListElement {
            question: "Tips Menggunakan CheckMate"
            answer: "1. Tambahkan informasi produk secara lengkap.\n2. Gunakan parameter yang relevan.\n3. Pilih pengaturan preferensi yang tepat.\n4. Bandingkan produk yang sejenis.\n5. Tinjau rincian peringkat dengan saksama."
        }
    }

    Sidebar {
        id: sideBar
        activeMenu: "help"

        anchors {
            left: parent.left
            top: parent.top
            bottom: parent.bottom
        }
    }

    Item {
        anchors {
            left: sideBar.right
            right: parent.right
            top: parent.top
            bottom: parent.bottom
            margins: 40
        }

        ScrollView {
            anchors.fill: parent
            visible: helpRoot.selectedIndex === -1

            Column {
                width: parent.width
                spacing: 15

                Repeater {
                    model: faqModel

                    delegate: Rectangle {
                        width: parent.width
                        height: 100

                        radius: 20
                        color: "#ffffff"

                        border.color: "#000000"
                        border.width: 1

                        Text {
                            anchors {
                                verticalCenter: parent.verticalCenter
                                left: parent.left
                                right: parent.right
                                leftMargin: 30
                                rightMargin: 30
                            }

                            text: model.question
                            wrapMode: Text.Wrap

                            color: "#000000"
                            font.family: "Inknut Antiqua"
                            font.pixelSize: 22
                        }

                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor

                            onClicked: {
                                helpRoot.selectedIndex = index
                            }
                        }
                    }
                }
            }
        }

        Rectangle {
            anchors.fill: parent
            visible: helpRoot.selectedIndex !== -1

            radius: 20
            color: "#ffffff"

            border.color: "#000000"
            border.width: 1

            Rectangle {
                id: backButton

                width: 120
                height: 40

                radius: 10
                color: "#f4f4f4"

                border.color: "#cccccc"

                anchors {
                    left: parent.left
                    top: parent.top
                    margins: 25
                }

                Text {
                    anchors.centerIn: parent
                    text: "← Kembali"

                    font.pixelSize: 16
                    font.bold: true
                }

                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor

                    onClicked: {
                        helpRoot.selectedIndex = -1
                    }
                }
            }

            ScrollView {
                anchors {
                    left: parent.left
                    right: parent.right
                    top: backButton.bottom
                    bottom: parent.bottom
                    margins: 30
                }

                Column {
                    width: parent.width
                    spacing: 20

                    Text {
                        width: parent.width

                        text: helpRoot.selectedIndex >= 0
                              ? faqModel.get(helpRoot.selectedIndex).question
                              : ""

                        wrapMode: Text.Wrap

                        font.family: "Inknut Antiqua"
                        font.pixelSize: 28
                        font.bold: true

                        color: "#000000"
                    }

                    Rectangle {
                        width: parent.width
                        height: 1
                        color: "#dddddd"
                    }

                    Text {
                        width: parent.width

                        text: helpRoot.selectedIndex >= 0
                              ? faqModel.get(helpRoot.selectedIndex).answer
                              : ""

                        wrapMode: Text.Wrap

                        font.family: "Inknut Antiqua"
                        font.pixelSize: 20

                        color: "#333333"
                    }
                }
            }
        }
    }
}