import QtQuick

Rectangle {
    enum Property_1 { Property_1_Variant3, Property_1_Variant2, Property_1_Default, Property_1_Variant4}

    id: lIDSA2

    property alias lIDSA_2Width: lIDSA_2.width
    property alias lIDSA_2WrapMode: lIDSA_2.wrapMode
    property alias rectangle_22BorderColor: rectangle_22.border.color
    property alias rectangle_22BorderWidth: rectangle_22.border.width
    property alias rectangle_22Radius: rectangle_22.radius

    property int property_2: LIDSA2.Property_1.Property_1_Default
    property string second: "LIDSA 2"

    height: 27
    width: 214

    color: "transparent"

    states: [
        State {
            name: "Property 1=Default"
            when: lIDSA2.property_2 === LIDSA2.Property_1.Property_1_Default
    
            PropertyChanges {
                y: -0.82
    
                target: rectangle_22
            }
            PropertyChanges {
                color: "#ffffff"
                target: rectangle_22
            }
            PropertyChanges {
                border.width: 0
                target: rectangle_22
            }
            PropertyChanges {
                border.color: "white"
                target: rectangle_22
            }
            PropertyChanges {
                radius: 0
                target: rectangle_22
            }
            PropertyChanges {
                width: 42
    
                target: lIDSA_2
            }
            PropertyChanges {
                font.weight: Font.Normal
                target: lIDSA_2
            }
            PropertyChanges {
                target: lIDSA_2
                wrapMode: Text.NoWrap
            }
        },
        State {
            name: "Property 1=Variant2"
            when: lIDSA2.property_2 === LIDSA2.Property_1.Property_1_Variant2
    
            PropertyChanges {
                y: 0
    
                target: rectangle_22
            }
            PropertyChanges {
                color: "#efefef"
                target: rectangle_22
            }
            PropertyChanges {
                border.width: 0
                target: rectangle_22
            }
            PropertyChanges {
                border.color: "white"
                target: rectangle_22
            }
            PropertyChanges {
                radius: 0
                target: rectangle_22
            }
            PropertyChanges {
                width: 42
    
                target: lIDSA_2
            }
            PropertyChanges {
                font.weight: Font.Normal
                target: lIDSA_2
            }
            PropertyChanges {
                target: lIDSA_2
                wrapMode: Text.NoWrap
            }
        },
        State {
            name: "Property 1=Variant3"
            when: lIDSA2.property_2 === LIDSA2.Property_1.Property_1_Variant3
    
            PropertyChanges {
                y: 0
    
                target: rectangle_22
            }
            PropertyChanges {
                color: "#efefef"
                target: rectangle_22
            }
            PropertyChanges {
                border.width: 0
                target: rectangle_22
            }
            PropertyChanges {
                border.color: "white"
                target: rectangle_22
            }
            PropertyChanges {
                radius: 0
                target: rectangle_22
            }
            PropertyChanges {
                width: 44
    
                target: lIDSA_2
            }
            PropertyChanges {
                font.weight: Font.Bold
                target: lIDSA_2
            }
            PropertyChanges {
                target: lIDSA_2
                wrapMode: Text.NoWrap
            }
        },
        State {
            name: "Property 1=Variant4"
            when: lIDSA2.property_2 === LIDSA2.Property_1.Property_1_Variant4
    
            PropertyChanges {
                y: 0
    
                target: rectangle_22
            }
            PropertyChanges {
                color: "#ffffff"
                target: rectangle_22
            }
            PropertyChanges {
                border.width: 0.25
                target: rectangle_22
            }
            PropertyChanges {
                border.color: "#000000"
                target: rectangle_22
            }
            PropertyChanges {
                radius: 5
                target: rectangle_22
            }
            PropertyChanges {
                width: 42
    
                target: lIDSA_2
            }
            PropertyChanges {
                font.weight: Font.Normal
                target: lIDSA_2
            }
            PropertyChanges {
                target: lIDSA_2
                wrapMode: Text.Wrap
            }
        }
    ]

    Rectangle {
        id: rectangle_22

        y: -0.82

        height: 27
        width: 214

        border.color: "white"
        border.width: 0
        color: "#ffffff"
        radius: 0
    }
    Text {
        id: lIDSA_2

        x: 12
        y: 2

        height: 23
        width: 42

        color: "#000000"
        font.family: "Inknut Antiqua"
        font.pixelSize: 9
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignLeft
        text: lIDSA2.second
        verticalAlignment: Text.AlignTop
        wrapMode: Text.NoWrap
    }
}