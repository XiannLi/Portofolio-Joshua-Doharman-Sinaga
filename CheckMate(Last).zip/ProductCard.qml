import QtQuick
import QtQuick.Effects
import QtQuick.Controls
import QtQuick.Shapes

Item {
    id: product

    property string productName: "Produk"
    property string productPrice: "0"
    property string productCurrency: "IDR"
    property string productDesc: "-"
    property url productImage: ""
    property var productParams: []

    signal editRequested()

    height: 230
    width: 230

    // 1. MASKER DASAR
    Rectangle {
        id: maskRect
        anchors.fill: parent
        color: "black"
        radius: 5
        visible: false
        layer.enabled: true
    }

    // 2. KONTAINER UTAMA KARTU
    Item {
        anchors.fill: parent
        layer.enabled: true
        layer.effect: MultiEffect {
            maskEnabled: true
            maskSource: maskRect
        }

        Image {
            x: 0; y: 0; width: 230; height: 180
            source: productImage.toString() !== "" ? productImage : Qt.resolvedUrl("assets/PicPlaceholder.png")
            fillMode: Image.PreserveAspectCrop
        }

        Rectangle {
            x: 0; y: 179; width: 230; height: 1
            color: "#e6e6e6"
        }

        Rectangle {
            x: 0; y: 180; width: 230; height: 50
            color: "#ffffff"

            Text {
                x: 15
                anchors.verticalCenter: parent.verticalCenter
                text: productName
                font.family: "Inknut Antiqua"
                font.pixelSize: 11
                font.weight: Font.Bold
                color: "#000000"
                width: 110
                elide: Text.ElideRight
            }

            Text {
                anchors.right: parent.right
                anchors.rightMargin: 15
                anchors.verticalCenter: parent.verticalCenter
                text: productCurrency + " " + productPrice
                font.family: "Inknut Antiqua"
                font.pixelSize: 11
                color: "#888888"
            }
        }
    }

    // 3. BORDER LUAR KARTU
    Rectangle {
        anchors.fill: parent
        color: "transparent"
        border.color: "#e6e6e6"
        border.width: 1
        radius: 5
    }

    // --- 4. DETEKSI KLIK UNTUK MEMBUKA DETAIL ---
    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        onClicked: detailPopup.open()
    }

    // --- 5. POPUP READ-ONLY (PENGGANTI ProductView.qml) ---
    Popup {
        id: detailPopup
        width: 800
        height: 533
        modal: true
        dim: true
        closePolicy: Popup.CloseOnPressOutside | Popup.CloseOnEscape

        Overlay.modal: Rectangle {
            color: Qt.rgba(0, 0, 0, 0.5)
        }

        parent: Overlay.overlay
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)

        padding: 0
        background: Rectangle {
            color: "#fdfdfd"
            radius: 10
        }

        contentItem: Item {
            anchors.fill: parent

            Item {
                x: 20; y: 41; height: 192; width: 240

                property bool hasRealImage: product.productImage.toString() !== "" && product.productImage.toString().indexOf("PicPlaceholder.png") === -1

                Rectangle {
                    height: 192; width: 240
                    border.color: "#cccccc"
                    border.width: 1
                    radius: 5
                    color: parent.hasRealImage ? "transparent" : "#f5f5f5"
                    z: 1
                }

                Item {
                    x: 84; y: 70.67; height: 60.33; width: 71
                    visible: !parent.hasRealImage
                    z: 2

                    Image {
                        x: 20
                        source: Qt.resolvedUrl("assets/ellipse_1.png")
                    }
                    Shape {
                        x: 25.33; y: 5.33; height: 21.32; width: 21.33
                        ShapePath {
                            fillColor: "#373737"; fillRule: ShapePath.WindingFill
                            joinStyle: ShapePath.MiterJoin; strokeColor: "transparent"; strokeWidth: 1
                            PathSvg {
                                path: "M 9.14285741533552 12.182856968470983 L 0 12.182856968470983 L 0 9.137142726353236 L 9.14285741533552 9.137142726353236 L 9.14285741533552 0 L 12.190476553780693 0 L 12.190476553780693 9.137142726353236 L 21.33333396911621 9.137142726353236 L 21.33333396911621 12.182856968470983 L 12.190476553780693 12.182856968470983 L 12.190476553780693 21.31999969482422 L 9.14285741533552 21.31999969482422 L 9.14285741533552 12.182856968470983 Z"
                            }
                        }
                    }
                    Text {
                        y: 49.33; height: 11; width: 72
                        color: "#000000"; font.family: "Inter"; font.italic: true; font.pixelSize: 9
                        text: "Add picture here"
                    }
                }

                Image {
                    anchors.fill: parent; anchors.margins: 4
                    source: product.productImage
                    fillMode: Image.PreserveAspectFit
                    visible: parent.hasRealImage
                    z: 3
                }
            }

            // --- Kolom Name ---
            Item {
                x: 313; y: 41; height: 50; width: 467
                Text { text: "Name"; font.family: "Inknut Antiqua"; font.pixelSize: 9; color: "#000000" }
                Rectangle {
                    y: 23; height: 27; width: 467
                    border.color: "#cccccc"; border.width: 1; radius: 5; color: "#f5f5f5"
                    Text {
                        x: 10; anchors.verticalCenter: parent.verticalCenter
                        text: product.productName
                        font.family: "Inknut Antiqua"; font.pixelSize: 11; color: "#000000"
                    }
                }
            }

            // --- Kolom Price ---
            Item {
                x: 313; y: 99; height: 50; width: 233
                Text { text: "Price"; font.family: "Inknut Antiqua"; font.pixelSize: 9; color: "#000000" }
                Rectangle {
                    y: 23; height: 27; width: 233
                    border.color: "#cccccc"; border.width: 1; radius: 5; color: "#f5f5f5"
                    Text {
                        x: 10; anchors.verticalCenter: parent.verticalCenter
                        text: product.productPrice
                        font.family: "Inknut Antiqua"; font.pixelSize: 11; color: "#000000"
                    }
                }
            }

            // --- Kolom Currency ---
            Item {
                x: 566; y: 99; height: 50; width: 214
                Text { text: "Currency"; font.family: "Inknut Antiqua"; font.pixelSize: 9; color: "#000000" }
                Rectangle {
                    y: 23; height: 27; width: 214
                    border.color: "#cccccc"; border.width: 1; radius: 5; color: "#f5f5f5"
                    Text {
                        x: 10; anchors.verticalCenter: parent.verticalCenter
                        text: product.productCurrency
                        font.family: "Inknut Antiqua"; font.pixelSize: 11; color: "#000000"
                    }
                }
            }

            // --- Kolom Description ---
            Item {
                x: 313; y: 157; height: 76; width: 467
                Text { text: "Description"; font.family: "Inknut Antiqua"; font.pixelSize: 9; color: "#000000" }
                Rectangle {
                    y: 23; height: 53; width: 467
                    border.color: "#cccccc"; border.width: 1; radius: 5; color: "#f5f5f5"
                    ScrollView {
                        anchors.fill: parent; anchors.margins: 8; clip: true
                        Text {
                            width: parent.width; wrapMode: Text.Wrap
                            text: product.productDesc
                            font.family: "Inknut Antiqua"; font.pixelSize: 11; color: "#000000"
                        }
                    }
                }
            }

            // --- Render Data Parameter Secara Dinamis ---
            Column {
                x: 20; y: 248; spacing: 15
                Repeater {
                    model: product.productParams
                    delegate: Item {
                        width: 760; height: 50

                        Text {
                            text: model.paramName !== undefined ? model.paramName : ""
                            font.family: "Inknut Antiqua"
                            font.pixelSize: 9
                            color: "#000000"
                        }

                        Rectangle {
                            y: 23; height: 27; width: 527
                            border.color: "#cccccc"; border.width: 1; radius: 5; color: "#f5f5f5"
                            Text {
                                x: 10; anchors.verticalCenter: parent.verticalCenter
                                text: model.value !== undefined ? model.value : ""
                                font.family: "Inknut Antiqua"; font.pixelSize: 11; color: "#000000"
                            }
                        }

                        Text { x: 546; text: "Unit"; font.family: "Inknut Antiqua"; font.pixelSize: 9; color: "#000000" }

                        Rectangle {
                            x: 546; y: 23; height: 27; width: 214
                            border.color: "#cccccc"; border.width: 1; radius: 5; color: "#f5f5f5"
                            Text {
                                x: 10; anchors.verticalCenter: parent.verticalCenter
                                // PERBAIKAN 3: Gunakan model.unit
                                text: model.unit !== undefined ? model.unit : ""
                                font.family: "Inknut Antiqua"; font.pixelSize: 11; color: "#000000"
                            }
                        }
                    }
                }
            }
            // --- Tombol Edit (Latar Biru) ---
            Rectangle {
                x: 712
                y: 14; width: 24; height: 24
                radius: 5

                color: editMouseArea.pressed ? "#0052cc" : "#007AFF"
                opacity: (editMouseArea.containsMouse && !editMouseArea.pressed) ? 0.8 : 1.0

                Image {
                    anchors.centerIn: parent
                    width: 14; height: 14
                    source: Qt.resolvedUrl("assets/edit.png")
                    fillMode: Image.PreserveAspectFit
                }

                MouseArea {
                    id: editMouseArea
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true

                    onClicked: {
                        detailPopup.close()
                        product.editRequested()
                    }
                }
            }

            // --- Tombol Exit (Kotak Merah) ---
            Rectangle {
                x: 756
                y: 14; width: 24; height: 24
                radius: 5

                color: exitMouseArea.pressed ? "#8a2e2e" : "#b83d3d"
                opacity: (exitMouseArea.containsMouse && !exitMouseArea.pressed) ? 0.8 : 1.0

                Shape {
                    anchors.centerIn: parent
                    height: 16; width: 16
                    ShapePath {
                        fillColor: "transparent"
                        strokeColor: "#ffffff"
                        strokeWidth: 2.5
                        capStyle: ShapePath.RoundCap

                        PathSvg {
                            path: "M 4 4 L 12 12 M 12 4 L 4 12"
                        }
                    }
                }

                MouseArea {
                    id: exitMouseArea
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true
                    onClicked: detailPopup.close()
                }
            }
        }
    }
}