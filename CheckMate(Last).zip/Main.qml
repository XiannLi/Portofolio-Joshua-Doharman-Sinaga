import QtQuick
import QtQuick.Controls
import CheckMate

Window {
    id: root

    visibility: Window.Maximized
    width: 1920
    height: 1080
    visible: true
    title: qsTr("CheckMate")

    // ── Font loaders ──────────────────────────────────────────────────────
    FontLoader { source: Qt.resolvedUrl("fonts/inknutantiqua-regular.ttf") }
    FontLoader { source: Qt.resolvedUrl("fonts/inknutantiqua-bold.ttf") }
    FontLoader { source: Qt.resolvedUrl("fonts/inknutantiqua-semibold.ttf") }
    FontLoader { source: Qt.resolvedUrl("fonts/inter-regular.ttf") }
    FontLoader { source: Qt.resolvedUrl("fonts/inter-semibold.ttf") }
    FontLoader { source: Qt.resolvedUrl("fonts/inter-italic.ttf") }

    // ── Navigation state ──────────────────────────────────────────────────
    property string currentScreen: "first"
    property string previousScreen: ""

    // GANTI currentNavParams MENJADI DUA ARRAY TERPISAH YANG AMAN:
    property var rawParamsData: []
    property var vfmParamsData: []

    property int selectedProductIndex: -1
    property var selectedProductData: null

    function navigateTo(screen, params) {
        previousScreen = currentScreen
        currentScreen = screen

        // Tangkap parameter dengan aman
        if (params) {
            rawParamsData = params.rawParams || []
            vfmParamsData = params.vfmParams || []
        }
    }

    function goBack() {
        if (previousScreen !== "")
            currentScreen = previousScreen
        else
            currentScreen = "dashboard"
    }

    // ── Screen container ──────────────────────────────────────────────────
    Item {
        id: screenContainer
        anchors.fill: parent

        // ── FIRST ────────────────────────────────────────────────────────
        Item {
            visible: currentScreen === "first"
            anchors.fill: parent

            // Memanggil komponen first.qml
            First {
                anchors.fill: parent
            }

            // Timer untuk pindah otomatis ke dashboard
            Timer {
                interval: 12000
                running: currentScreen === "first"
                repeat: false
                onTriggered: root.navigateTo("dashboard")
            }

            MouseArea {
                anchors.fill: parent
                onClicked: root.navigateTo("dashboard")
            }
        }

        // ── DASHBOARD (no products) ───────────────────────────────────────
        Item {
            visible: currentScreen === "dashboard"
            anchors.fill: parent

            Dashboard { x: 0; y: 0 }
        }

        // ── ADD PRODUCT (popup step 0) ────────────────────────────────────
        Item {
            visible: currentScreen === "addProduct"
            anchors.fill: parent

            Dashboard { x: 0; y: 0; opacity: 0.35 }

            PopupAddProduct {
                anchors.centerIn: parent
            }

            // Dismiss popup by clicking outside
            MouseArea {
                x: 0; y: 0; width: 320; height: 1024
                onClicked: root.navigateTo("dashboard")
            }
            // Next → Par1
            MouseArea {
                x: 960; y: 900; width: 200; height: 60
                onClicked: root.navigateTo("addProductPar1")
            }
        }

        // ── COMPARE RESULT ────────────────────────────────────────────────
        Item {
            visible: currentScreen === "compareResult"
            anchors.fill: parent

            CompareResult {
                x: 0; y: 0
                // Lempar data array ke CompareResult
                rawParams: root.rawParamsData
                vfmParams: root.vfmParamsData
            }

            MouseArea { x: 20; y: 61;  width: 240; height: 70; onClicked: root.navigateTo("dashboard") }
            MouseArea { x: 20; y: 185; width: 240; height: 70; onClicked: root.navigateTo("help") }
            MouseArea { x: 20; y: 309; width: 240; height: 70; onClicked: root.navigateTo("credit") }
        }

        // ── COMPARE NOTE ──────────────────────────────────────────────────
        Item {
            visible: currentScreen === "compareNote"
            anchors.fill: parent

            Rectangle { anchors.fill: parent; color: "#80000000" }
            CompareNote { anchors.centerIn: parent }

            MouseArea {
                anchors.fill: parent
                onClicked: root.goBack()
            }
        }

        // ── HELP ──────────────────────────────────────────────────────────
        Item {
            visible: currentScreen === "help"
            anchors.fill: parent

            Help { x: 0; y: 0 }

            MouseArea { x: 20; y: 61;  width: 240; height: 70; onClicked: root.navigateTo("dashboard") }
            MouseArea { x: 20; y: 309; width: 240; height: 70; onClicked: root.navigateTo("credit") }
        }

        // ── CREDIT ────────────────────────────────────────────────────────
        Item {
            visible: currentScreen === "credit"
            anchors.fill: parent

            Credit { x: 0; y: 0 }

            MouseArea { x: 20; y: 61;  width: 240; height: 70; onClicked: root.navigateTo("dashboard") }
            MouseArea { x: 20; y: 185; width: 240; height: 70; onClicked: root.navigateTo("help") }
        }
    }
}
