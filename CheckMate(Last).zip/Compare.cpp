#include "Compare.h"
#include <cmath>
#include <limits>
#include <algorithm>

Compare::Compare(QObject *parent) : QObject(parent), m_totalTableWidth(0.0)
{
    m_bestPriceText = "-";
    m_bestValueText = "-";
    m_bestProductText = "-";
}

QString Compare::bestPriceText() const { return m_bestPriceText; }
QString Compare::bestValueText() const { return m_bestValueText; }
QString Compare::bestProductText() const { return m_bestProductText; }
QVariantList Compare::tableHeaders() const { return m_tableHeaders; }
QVariantList Compare::tableRows() const { return m_tableRows; }
QVariantList Compare::columnWidths() const { return m_columnWidths; }
double Compare::totalTableWidth() const { return m_totalTableWidth; }

void Compare::calculate(const QVariantList& products,
                        const QVariantList& rawParams,
                        const QVariantList& vfmParams,
                        double availableWidth)
{
    m_bestPriceText = "-";
    m_bestValueText = "-";
    m_bestProductText = "-";
    m_tableHeaders.clear();
    m_tableRows.clear();
    m_columnWidths.clear();
    m_totalTableWidth = 0.0;

    if (products.isEmpty()) {
        emit calculationDone();
        return;
    }

    double bestPriceVal = std::numeric_limits<double>::infinity();
    QVector<ScoreData> scores(products.size());

    for (int i = 0; i < products.size(); ++i) {
        QVariantMap p = products[i].toMap();
        double pPrice = p["price"].toDouble();

        // 1. BEST PRICE (Murni Harga Terendah)
        if (pPrice > 0 && pPrice < bestPriceVal) {
            bestPriceVal = pPrice;
            m_bestPriceText = p["name"].toString();
        }

        scores[i].index = i;
        scores[i].name = p["name"].toString();
        scores[i].totalScore = 0;
        scores[i].vfmScore = 0; // Tracking khusus untuk Best Value
    }

    auto getParam = [](const QVariantMap& prod, const QString& pName, double& outVal, QString& outUnit) -> bool {
        QVariantList params = prod["parameters"].toList();
        for (const QVariant& paramVar : params) {
            QVariantMap param = paramVar.toMap();
            if (param["paramName"].toString() == pName) {
                outVal = param["value"].toDouble();
                outUnit = param["unit"].toString();
                return true;
            }
        }
        return false;
    };

    // Fungsi Sistem Poin Borda yang telah diperbaiki
    auto applyRankScores = [&](std::function<double(const QVariantMap&)> evalFunc, const QString& sortMode, bool isVfm = false) {
        struct RankItem { int idx; double val; };
        QVector<RankItem> valid;

        for (int i = 0; i < products.size(); ++i) {
            double v = evalFunc(products[i].toMap());
            if (!std::isnan(v)) {
                valid.append({i, v});
            }
        }

        // Sorting dinamis berdasarkan permintaan antarmuka
        std::sort(valid.begin(), valid.end(), [&](const RankItem& a, const RankItem& b) {
            return sortMode == "highest" ? (a.val > b.val) : (a.val < b.val);
        });

        int N = valid.size();
        for (int i = 0; i < N; ++i) {
            int pointsEarned = (N - i);
            scores[valid[i].idx].totalScore += pointsEarned;

            // Jika ini kompetisi VFM, tambahkan ke skor spesifik VFM
            if (isVfm) {
                scores[valid[i].idx].vfmScore += pointsEarned;
            }
        }
    };

    // 2. Evaluasi Skor Harga (Dianggap setara dengan Raw)
    applyRankScores([](const QVariantMap& p) {
        double price = p["price"].toDouble();
        return price > 0 ? price : std::numeric_limits<double>::quiet_NaN();
    }, "lowest", false);

    // 3. Evaluasi Skor Raw Parameters
    for (const QVariant& rVar : rawParams) {
        QVariantMap rParam = rVar.toMap();
        QString pName = rParam["paramName"].toString();
        QString sortMode = rParam["sortMode"].toString();

        applyRankScores([&](const QVariantMap& p) {
            double val = 0;
            QString unit;
            if (getParam(p, pName, val, unit)) return val;
            return std::numeric_limits<double>::quiet_NaN(); // Data kosong dianulir (0 poin)
        }, sortMode, false);
    }

    // 4. Evaluasi Skor VFM secara Per-Parameter (TIDAK LAGI DIRATA-RATA)
    for (const QVariant& vVar : vfmParams) {
        QVariantMap vParam = vVar.toMap();
        QString pName = vParam["paramName"].toString();
        QString sortMode = vParam["sortMode"].toString(); // BACA INSTRUKSI HIGHEST/LOWEST

        applyRankScores([&](const QVariantMap& p) {
            double val = 0;
            QString unit;
            double price = p["price"].toDouble();
            if (getParam(p, pName, val, unit) && val > 0 && price > 0) {
                return price / val;
            }
            return std::numeric_limits<double>::quiet_NaN();
        }, sortMode, true); // Flag true menandakan ini skor VFM
    }

    // 5. Mencari Pemenang "Best Value"
    int maxVfmScore = -1;
    for (const auto& s : scores) {
        if (s.vfmScore > maxVfmScore && s.vfmScore > 0) {
            maxVfmScore = s.vfmScore;
            m_bestValueText = s.name;
        }
    }

    // 6. Mencari Pemenang "Best Product" (Total Seluruh Poin)
    int maxTotal = -1;
    for (const auto& s : scores) {
        if (s.totalScore > maxTotal && s.totalScore > 0) {
            maxTotal = s.totalScore;
            m_bestProductText = s.name;
        }
    }

    // --- LOGIKA PENYUSUNAN TABEL (Sama dengan Sebelumnya) ---
    QStringList headers = {"No", "Name", "Price"};
    QList<double> cWidths = {45.0, 180.0, 130.0};

    for (const QVariant& rVar : rawParams) {
        headers << rVar.toMap()["paramName"].toString();
        cWidths << 160.0;
    }
    for (const QVariant& vVar : vfmParams) {
        headers << "Price / " + vVar.toMap()["paramName"].toString();
        cWidths << 200.0;
    }

    double tWidth = 0.0;
    for (double w : cWidths) tWidth += w;

    if (tWidth < availableWidth && cWidths.size() > 1) {
        double extraSpace = availableWidth - tWidth;
        double perCol = extraSpace / (cWidths.size() - 1);
        for (int i = 1; i < cWidths.size(); ++i) {
            cWidths[i] += perCol;
        }
        tWidth = availableWidth;
    }

    for (const QString& h : headers) m_tableHeaders << h;
    for (double w : cWidths) m_columnWidths << w;
    m_totalTableWidth = tWidth;

    for (int i = 0; i < products.size(); ++i) {
        QVariantMap p = products[i].toMap();
        QVariantList row;
        QString cur = p["currency"].toString();
        cur = (cur == "IDR") ? "Rp" : (cur + " ");

        row << QString::number(i + 1);
        row << p["name"].toString();

        double priceVal = p["price"].toDouble();
        row << cur + (priceVal > 0 ? QString::number(priceVal, 'g', 10) : "0");

        for (const QVariant& rVar : rawParams) {
            QString pName = rVar.toMap()["paramName"].toString();
            double val = 0;
            QString unit;
            if (getParam(p, pName, val, unit)) {
                row << QString::number(val, 'g', 10) + " " + unit;
            } else {
                row << "-";
            }
        }

        for (const QVariant& vVar : vfmParams) {
            QString pName = vVar.toMap()["paramName"].toString();
            double val = 0;
            QString unit;
            if (getParam(p, pName, val, unit) && val > 0 && priceVal > 0) {
                double ratio = priceVal / val;
                QString ratioStr = (std::fmod(ratio, 1.0) == 0.0) ? QString::number(ratio) : QString::number(ratio, 'f', 2);
                row << cur + ratioStr + " / " + unit;
            } else {
                row << "-";
            }
        }
        m_tableRows << QVariant::fromValue(row);
    }

    emit calculationDone();
}