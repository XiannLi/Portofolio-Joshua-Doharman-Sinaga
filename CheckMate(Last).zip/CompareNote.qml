import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: compareNoteRoot

    property real maxPopupWidth: Overlay.overlay ? Overlay.overlay.width - 95 : 1000
    property real maxPopupHeight: Overlay.overlay ? Overlay.overlay.height - 120 : 800

    width: Math.min(550, maxPopupWidth)

    function getSectionHeight(count) {
        return count === 0 ? 96 : 46 + (50 * count);
    }

    property int exactContentHeight: getSectionHeight(rawModel.count) + getSectionHeight(vfmModel.count) + 117

    height: Math.min(exactContentHeight + 42, maxPopupHeight)

    color: "#ffffff"
    radius: 10
    border.color: "#e6e6e6"
    border.width: 1

    signal closeRequested()

    ListModel { id: rawModel }
    ListModel { id: vfmModel }

    property bool hasSelection: false

    function checkSelection() {
        var sel = false;
        for (var i = 0; i < rawModel.count; i++) {
            if (rawModel.get(i).isSelected) { sel = true; break; }
        }
        if (!sel) {
            for (var j = 0; j < vfmModel.count; j++) {
                if (vfmModel.get(j).isSelected) { sel = true; break; }
            }
        }
        hasSelection = sel;
    }

    function updateRawSelectAll() {
        if (rawModel.count === 0) return false;
        for (var i = 0; i < rawModel.count; i++) {
            if (!rawModel.get(i).isSelected) return false;
        }
        return true;
    }

    function updateVfmSelectAll() {
        if (vfmModel.count === 0) return false;
        for (var i = 0; i < vfmModel.count; i++) {
            if (!vfmModel.get(i).isSelected) return false;
        }
        return true;
    }

    function buildParameterList(productModel) {
        rawModel.clear()
        vfmModel.clear()
        rawSelectAllBox.isChecked = false
        vfmSelectAllBox.isChecked = false

        var uniqueParams = {}
        for (var i = 0; i < productModel.count; i++) {
            var prod = productModel.get(i)
            var params = prod.parameters || []
            var paramLen = params.count !== undefined ? params.count : params.length

            for (var j = 0; j < paramLen; j++) {
                var pName = (params.count !== undefined ? params.get(j).paramName : params[j].paramName)
                if (!uniqueParams[pName]) {
                    uniqueParams[pName] = true
                    rawModel.append({ "paramName": pName, "isSelected": false, "sortMode": "highest" })
                    vfmModel.append({ "paramName": pName, "isSelected": false, "sortMode": "lowest" })
                }
            }
        }
        checkSelection()
    }

    Item {
        anchors.fill: parent
        anchors.margins: 20

        ScrollView {
            id: scrollView
            anchors.fill: parent
            contentWidth: width
            contentHeight: compareNoteRoot.exactContentHeight
            clip: true

            ScrollBar.vertical.policy: ScrollBar.AsNeeded

            Column {
                id: mainContainer
                width: scrollView.width - (scrollView.ScrollBar.vertical.visible ? 15 : 0)
                spacing: 20

                // ==========================================
                // --- BAGIAN 1: RAW PARAMETER ---
                // ==========================================
                Column {
                    width: parent.width
                    spacing: 10

                    Item {
                        width: parent.width; height: 35
                        Column {
                            anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter
                            Text { text: "1. Raw Parameter"; font.family: "Inknut Antiqua"; font.pixelSize: 14; font.weight: Font.Bold; color: "#000000" }
                            Text { text: "Compare actual values (e.g., Who is the heaviest?)"; font.family: "Inter"; font.pixelSize: 10; font.italic: true; color: "#888888" }
                        }

                        Row {
                            anchors.right: parent.right
                            anchors.verticalCenter: parent.verticalCenter
                            height: 16
                            spacing: 8

                            Rectangle {
                                id: rawSelectAllBox
                                width: 16; height: 16; radius: 3; border.color: "#cccccc"; border.width: 1
                                anchors.verticalCenter: parent.verticalCenter
                                property bool isChecked: false
                                color: isChecked ? "#4CAF50" : "#ffffff"
                                Text { anchors.centerIn: parent; text: "✓"; color: "#ffffff"; font.pixelSize: 10; font.bold: true; visible: parent.isChecked }
                                MouseArea {
                                    anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                    onClicked: {
                                        parent.isChecked = !parent.isChecked
                                        for (var i = 0; i < rawModel.count; i++) rawModel.setProperty(i, "isSelected", parent.isChecked)
                                        compareNoteRoot.checkSelection()
                                    }
                                }
                            }
                            Text {
                                text: "Select All"
                                font.family: "Inknut Antiqua"
                                font.pixelSize: 10
                                anchors.verticalCenter: parent.verticalCenter
                                // PERBAIKAN MUTLAK: Mendongkrak teks ke atas secara paksa melewati padding
                                anchors.verticalCenterOffset: -2
                            }
                        }
                    }

                    Rectangle { width: parent.width; height: 1; color: "#e6e6e6" }

                    Text {
                        width: parent.width; height: visible ? 40 : 0
                        text: "No custom parameters available."
                        font.family: "Inknut Antiqua"; font.pixelSize: 12; color: "#888888"
                        verticalAlignment: Text.AlignVCenter; horizontalAlignment: Text.AlignHCenter
                        visible: rawModel.count === 0
                    }

                    Repeater {
                        model: rawModel
                        delegate: Rectangle {
                            width: parent.width; height: 40; radius: 5
                            color: model.isSelected ? "#f5faf8" : "transparent"
                            RowLayout {
                                anchors.fill: parent; anchors.leftMargin: 10; anchors.rightMargin: 10; spacing: 12
                                Rectangle {
                                    Layout.alignment: Qt.AlignVCenter; Layout.preferredWidth: 16; Layout.preferredHeight: 16; radius: 3; border.color: "#cccccc"; border.width: 1
                                    color: model.isSelected ? "#4CAF50" : "#ffffff"
                                    Text { anchors.centerIn: parent; text: "✓"; color: "#ffffff"; font.pixelSize: 10; font.bold: true; visible: model.isSelected }
                                    MouseArea {
                                        anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                        onClicked: {
                                            var newVal = !model.isSelected;
                                            rawModel.setProperty(index, "isSelected", newVal);
                                            rawSelectAllBox.isChecked = compareNoteRoot.updateRawSelectAll();
                                            compareNoteRoot.checkSelection();
                                        }
                                    }
                                }
                                Text { text: model.paramName; font.family: "Inknut Antiqua"; font.pixelSize: 12; color: model.isSelected ? "#000000" : "#888888"; Layout.fillWidth: true; elide: Text.ElideRight }
                                Rectangle {
                                    Layout.preferredWidth: 80; Layout.preferredHeight: 26; radius: 13
                                    color: model.sortMode === "highest" ? "#4CAF50" : "#E53935"
                                    opacity: model.isSelected ? 1.0 : 0.0; visible: opacity > 0
                                    Behavior on opacity { NumberAnimation { duration: 250 } }
                                    Text { anchors.centerIn: parent; text: model.sortMode === "highest" ? "↑ Highest" : "↓ Lowest"; color: "#ffffff"; font.family: "Inter"; font.pixelSize: 10; font.weight: Font.Bold }
                                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: rawModel.setProperty(index, "sortMode", (model.sortMode === "highest") ? "lowest" : "highest") }
                                }
                            }
                        }
                    }
                }

                Rectangle { width: parent.width; height: 1; color: "#cccccc" }

                // ==========================================
                // --- BAGIAN 2: VALUE FOR MONEY (VFM) ---
                // ==========================================
                Column {
                    width: parent.width
                    spacing: 10

                    Item {
                        width: parent.width; height: 35
                        Column {
                            anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter
                            Text { text: "2. Value for Money (VFM)"; font.family: "Inknut Antiqua"; font.pixelSize: 14; font.weight: Font.Bold; color: "#000000" }
                            Text { text: "Compare Price / Parameter ratio"; font.family: "Inter"; font.pixelSize: 10; font.italic: true; color: "#888888" }
                        }

                        Row {
                            anchors.right: parent.right
                            anchors.verticalCenter: parent.verticalCenter
                            height: 16
                            spacing: 8

                            Rectangle {
                                id: vfmSelectAllBox
                                width: 16; height: 16; radius: 3; border.color: "#cccccc"; border.width: 1
                                anchors.verticalCenter: parent.verticalCenter
                                property bool isChecked: false
                                color: isChecked ? "#4CAF50" : "#ffffff"
                                Text { anchors.centerIn: parent; text: "✓"; color: "#ffffff"; font.pixelSize: 10; font.bold: true; visible: parent.isChecked }
                                MouseArea {
                                    anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                    onClicked: {
                                        parent.isChecked = !parent.isChecked
                                        for (var i = 0; i < vfmModel.count; i++) vfmModel.setProperty(i, "isSelected", parent.isChecked)
                                        compareNoteRoot.checkSelection()
                                    }
                                }
                            }
                            Text {
                                text: "Select All"
                                font.family: "Inknut Antiqua"
                                font.pixelSize: 10
                                anchors.verticalCenter: parent.verticalCenter
                                anchors.verticalCenterOffset: -2
                            }
                        }
                    }

                    Rectangle { width: parent.width; height: 1; color: "#e6e6e6" }

                    Text {
                        width: parent.width; height: visible ? 40 : 0
                        text: "No custom parameters available."
                        font.family: "Inknut Antiqua"; font.pixelSize: 12; color: "#888888"
                        verticalAlignment: Text.AlignVCenter; horizontalAlignment: Text.AlignHCenter
                        visible: vfmModel.count === 0
                    }

                    Repeater {
                        model: vfmModel
                        delegate: Rectangle {
                            width: parent.width; height: 40; radius: 5
                            color: model.isSelected ? "#f5faf8" : "transparent"
                            RowLayout {
                                anchors.fill: parent; anchors.leftMargin: 10; anchors.rightMargin: 10; spacing: 12
                                Rectangle {
                                    Layout.alignment: Qt.AlignVCenter; Layout.preferredWidth: 16; Layout.preferredHeight: 16; radius: 3; border.color: "#cccccc"; border.width: 1
                                    color: model.isSelected ? "#4CAF50" : "#ffffff"
                                    Text { anchors.centerIn: parent; text: "✓"; color: "#ffffff"; font.pixelSize: 10; font.bold: true; visible: model.isSelected }
                                    MouseArea {
                                        anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                        onClicked: {
                                            var newVal = !model.isSelected;
                                            vfmModel.setProperty(index, "isSelected", newVal);
                                            vfmSelectAllBox.isChecked = compareNoteRoot.updateVfmSelectAll();
                                            compareNoteRoot.checkSelection();
                                        }
                                    }
                                }
                                Text { text: model.paramName; font.family: "Inknut Antiqua"; font.pixelSize: 12; color: model.isSelected ? "#000000" : "#888888"; Layout.fillWidth: true; elide: Text.ElideRight }
                                Rectangle {
                                    Layout.preferredWidth: 80; Layout.preferredHeight: 26; radius: 13
                                    color: model.sortMode === "highest" ? "#4CAF50" : "#E53935"
                                    opacity: model.isSelected ? 1.0 : 0.0; visible: opacity > 0
                                    Behavior on opacity { NumberAnimation { duration: 250 } }
                                    Text { anchors.centerIn: parent; text: model.sortMode === "highest" ? "↑ Highest" : "↓ Lowest"; color: "#ffffff"; font.family: "Inter"; font.pixelSize: 10; font.weight: Font.Bold }
                                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: vfmModel.setProperty(index, "sortMode", (model.sortMode === "highest") ? "lowest" : "highest") }
                                }
                            }
                        }
                    }
                }

                Rectangle { width: parent.width; height: 1; color: "#e6e6e6" }

                // --- FOOTER ---
                Item {
                    width: parent.width; height: 35

                    Item {
                        width: 120; height: 35
                        anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter

                        Rectangle {
                            anchors.fill: parent
                            radius: 5
                            color: generateBtnMouseArea.pressed ? "#586F74" : "#7E999E"
                            opacity: !compareNoteRoot.hasSelection ? 0.5 : (generateBtnMouseArea.containsMouse && !generateBtnMouseArea.pressed ? 0.8 : 1.0)
                        }

                        Text {
                            anchors.centerIn: parent;
                            text: "View Results";
                            color: "#ffffff";
                            font.family: "Inknut Antiqua";
                            font.pixelSize: 12;
                            font.weight: Font.Bold
                            opacity: compareNoteRoot.hasSelection ? 1.0 : 0.5
                        }

                        MouseArea {
                            id: generateBtnMouseArea
                            anchors.fill: parent
                            enabled: compareNoteRoot.hasSelection
                            cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                            hoverEnabled: true
                            onClicked: {
                                // Ekstrak parameter yang dicentang
                                var selectedRaw = [];
                                for(var i=0; i<rawModel.count; i++) {
                                    if(rawModel.get(i).isSelected) {
                                        selectedRaw.push({"paramName": rawModel.get(i).paramName, "sortMode": rawModel.get(i).sortMode});
                                    }
                                }
                                var selectedVfm = [];
                                for(var j=0; j<vfmModel.count; j++) {
                                    if(vfmModel.get(j).isSelected) {
                                        selectedVfm.push({"paramName": vfmModel.get(j).paramName, "sortMode": vfmModel.get(j).sortMode});
                                    }
                                }

                                compareNoteRoot.closeRequested()
                                // Kirim data parameter yang dipilih ke halaman CompareResult
                                root.navigateTo("compareResult", { "rawParams": selectedRaw, "vfmParams": selectedVfm })
                            }
                        }
                    }
                }
            }
        }
    }
}