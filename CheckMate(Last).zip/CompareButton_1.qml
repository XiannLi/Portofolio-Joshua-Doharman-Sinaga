import QtQuick

Rectangle {
    enum Property_1 { Property_1_Default, Property_1_Variant2, Property_1_Variant3, Property_1_Variant4}

    id: compareButton

    property int property_2: CompareButton_1.Property_1.Property_1_Default

    height: 58
    width: 100

    color: "transparent"
    opacity: 1

    states: [
        State {
            name: "Property 1=Default"
            when: compareButton.property_2 === CompareButton_1.Property_1.Property_1_Default
    
            PropertyChanges {
                opacity: 1
                target: compareButton
            }
            PropertyChanges {
                y: -2
    
                target: rectangle_5
            }
            PropertyChanges {
                source: Qt.resolvedUrl("assets/rectangle_5.png")
                target: rectangle_5
            }
            PropertyChanges {
                y: 8.61
    
                target: compare
            }
            PropertyChanges {
                height: 39.31
    
                target: compare
            }
            PropertyChanges {
                color: "#80000000"
                target: compare
            }
            PropertyChanges {
                target: compare
                wrapMode: Text.Wrap
            }
        },
        State {
            name: "Property 1=Variant2"
            when: compareButton.property_2 === CompareButton_1.Property_1.Property_1_Variant2
    
            PropertyChanges {
                opacity: 1
                target: compareButton
            }
            PropertyChanges {
                y: -0.55
    
                target: rectangle_5
            }
            PropertyChanges {
                source: Qt.resolvedUrl("assets/rectangle_8.png")
                target: rectangle_5
            }
            PropertyChanges {
                y: 8.45
    
                target: compare
            }
            PropertyChanges {
                height: 39
    
                target: compare
            }
            PropertyChanges {
                color: "#000000"
                target: compare
            }
            PropertyChanges {
                target: compare
                wrapMode: Text.NoWrap
            }
        },
        State {
            name: "Property 1=Variant3"
            when: compareButton.property_2 === CompareButton_1.Property_1.Property_1_Variant3
    
            PropertyChanges {
                opacity: 0.80
                target: compareButton
            }
            PropertyChanges {
                y: -0.55
    
                target: rectangle_5
            }
            PropertyChanges {
                source: Qt.resolvedUrl("assets/rectangle_7.png")
                target: rectangle_5
            }
            PropertyChanges {
                y: 8.45
    
                target: compare
            }
            PropertyChanges {
                height: 39
    
                target: compare
            }
            PropertyChanges {
                color: "#000000"
                target: compare
            }
            PropertyChanges {
                target: compare
                wrapMode: Text.NoWrap
            }
        },
        State {
            name: "Property 1=Variant4"
            when: compareButton.property_2 === CompareButton_1.Property_1.Property_1_Variant4
    
            PropertyChanges {
                opacity: 1
                target: compareButton
            }
            PropertyChanges {
                y: -2
    
                target: rectangle_5
            }
            PropertyChanges {
                source: Qt.resolvedUrl("assets/rectangle_6.png")
                target: rectangle_5
            }
            PropertyChanges {
                y: 8.61
    
                target: compare
            }
            PropertyChanges {
                height: 39.31
    
                target: compare
            }
            PropertyChanges {
                color: "#f5f5f5"
                target: compare
            }
            PropertyChanges {
                target: compare
                wrapMode: Text.Wrap
            }
        }
    ]

    Image {
        id: rectangle_5

        x: -2
        y: -2

        source: Qt.resolvedUrl("assets/rectangle_5.png")
    }
    Text {
        id: compare

        x: 12
        y: 8.61

        height: 39.31
        width: 77

        color: "#80000000"
        font.family: "Inknut Antiqua"
        font.pixelSize: 15
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignLeft
        text: "Compare"
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignTop
        wrapMode: Text.Wrap
    }
}