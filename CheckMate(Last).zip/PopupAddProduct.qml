import QtQuick
import QtQuick.Shapes
import QtQuick.Dialogs
import QtQuick.Controls
import QtQuick.Effects
import QtCore

Rectangle {
    id: popupAddProduct

    height: 533
    width: 800

    clip: true
    color: "#fdfdfd"

    property url selectedImage: ""

    property var availableIds: [1, 2, 3, 4]

    signal productSaved(var productData)

    ListModel {
        id: paramModel
    }

    function saveData() {
        if (nameInput.text.trim() === "") {
            console.log("Error: Nama produk tidak boleh kosong!")
            return
        }

        if (priceInput.text.trim() === "") {
            console.log("Error: Harga produk tidak boleh kosong!")
            return
        }

        for (var j = 0; j < paramModel.count; j++) {
            var unitValue = paramModel.get(j).selectedUnit;
            if (unitValue === "None" || unitValue.trim() === "") {
                console.log("Error: Unit pada parameter belum dipilih!")
                return
            }
        }

        var dataToSave = {
            "image": popupAddProduct.selectedImage == "" ? Qt.resolvedUrl("assets/PicPlaceholder.png").toString() : popupAddProduct.selectedImage.toString(),
            "name": nameInput.text,
            "price": parseFloat(priceInput.text) || 0,
            "currency": popupAddProduct.currentCurrency,
            "description": descInput.text,
            "parameters": []
        }

        for (var i = 0; i < paramModel.count; i++) {
            var item = paramModel.get(i)
            dataToSave.parameters.push({
                "paramName": item.paramName,
                "value": item.inputText,
                "unit": item.selectedUnit
            })
        }

        console.log("Mengirim data ke C++ untuk disimpan...");

        if (editIndex !== -1) {
            var allData = FileIO.readProducts();
            if (allData && allData.length > editIndex) {
                allData[editIndex] = dataToSave;
                FileIO.clearAllProducts();
                for (var k = 0; k < allData.length; k++) {
                    FileIO.saveProduct(allData[k]);
                }
            }
        } else {
            FileIO.saveProduct(dataToSave);
        }

        popupAddProduct.productSaved(dataToSave);
        popupAddProduct.resetPopup();
}

    function resetPopup() {
        selectedImage = ""
        paramModel.clear()

        availableIds = [1, 2, 3, 4]

        editIndex = -1

        currentCurrency = "IDR"
        nameInput.clear()
        priceInput.clear()
        descInput.clear()
    }

    property int editIndex: -1

    function loadDataForEdit(productData, index) {
        resetPopup()

        editIndex = index

        if (productData.image.toString().indexOf("PicPlaceholder.png") !== -1) {
            selectedImage = ""
        } else {
            selectedImage = productData.image
        }

        nameInput.text = productData.name
        priceInput.text = productData.price.toString()
        currentCurrency = productData.currency
        descInput.text = productData.description

        var params = productData.parameters || []
        var paramLen = params.count !== undefined ? params.count : params.length

        for (var i = 0; i < paramLen; i++) {
            var p = params.count !== undefined ? params.get(i) : params[i]
            var slotId = availableIds.shift()

            paramModel.append({
                "paramName": p.paramName,
                "inputText": p.value,
                "selectedUnit": p.unit,
                "slotId": slotId,
                "isCustomUnit": (p.unit !== "None")
            })
        }
    }

    onVisibleChanged: {
        if (!visible) {
            resetPopup()
        }
    }

    Item {
        id: add_Pic

        x: 20
        y: 41

        height: 192
        width: 240

        FileDialog {
            id: imageFileDialog
            title: "Pilih Gambar Produk"
            currentFolder: StandardPaths.writableLocation(StandardPaths.PicturesLocation)
            nameFilters: ["Image files (*.png *.jpg *.jpeg)"]
            onAccepted: {
                popupAddProduct.selectedImage = selectedFile
            }
        }
        Rectangle {
            id: rectangle_18

            height: 192
            width: 240

            border.color: popupAddProduct.selectedImage != "" ? "#000000" : "#adadad"
            border.width: 1
            color: "#1affffff"
            z: 1
        }
        Item {
            id: group_22

            x: 84
            y: 70.67

            height: 60.33
            width: 71
            visible: popupAddProduct.selectedImage == ""

            Image {
                id: ellipse_1

                x: 20

                source: Qt.resolvedUrl("assets/ellipse_1.png")
            }
            Shape {
                id: _vector

                x: 25.33
                y: 5.33

                height: 21.32
                width: 21.33

                ShapePath {
                    id: _vector_ShapePath0

                    fillColor: "#373737"
                    fillRule: ShapePath.WindingFill
                    joinStyle: ShapePath.MiterJoin
                    strokeColor: "#00000000"
                    strokeStyle: ShapePath.SolidLine
                    strokeWidth: 1

                    PathSvg {
                        id: _vector_ShapePath0_PathSvg0

                        path: "M 9.14285741533552 12.182856968470983 L 0 12.182856968470983 L 0 9.137142726353236 L 9.14285741533552 9.137142726353236 L 9.14285741533552 0 L 12.190476553780693 0 L 12.190476553780693 9.137142726353236 L 21.33333396911621 9.137142726353236 L 21.33333396911621 12.182856968470983 L 12.190476553780693 12.182856968470983 L 12.190476553780693 21.31999969482422 L 9.14285741533552 21.31999969482422 L 9.14285741533552 12.182856968470983 Z"
                    }
                }
            }
            Text {
                id: add_picture_here

                y: 49.33

                height: 11
                width: 72

                color: "#000000"
                font.family: "Inter"
                font.italic: true
                font.pixelSize: 9
                font.weight: Font.Normal
                horizontalAlignment: Text.AlignLeft
                text: "Add picture here"
                textFormat: Text.PlainText
                verticalAlignment: Text.AlignTop
            }
        }
        Image {
            id: displayedImage
            anchors.fill: parent
            anchors.margins: 4
            source: popupAddProduct.selectedImage
            fillMode: Image.PreserveAspectFit
            visible: popupAddProduct.selectedImage != ""
            z: 2
        }
        MouseArea {
            id: mainMouseArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: popupAddProduct.selectedImage == "" ? Qt.PointingHandCursor : Qt.ArrowCursor
            propagateComposedEvents: true
            onClicked: {
                if (popupAddProduct.selectedImage == "") imageFileDialog.open()
            }
            z: 3
        }
        Rectangle {
            id: hoverOverlay
            width: parent.width
            height: parent.height / 3
            anchors.bottom: parent.bottom
            color: "#80000000"
            z: 5
            visible: popupAddProduct.selectedImage != "" && (mainMouseArea.containsMouse || mouseAreaChange.containsMouse || mouseAreaRemove.containsMouse)

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {}
            }

            Row {
                anchors.fill: parent

                Item {
                    width: parent.width / 2
                    height: parent.height

                    Rectangle {
                        id: changeBtnContainer
                        width: 44; height: 44; radius: 22
                        anchors.centerIn: parent
                        opacity: mouseAreaChange.containsMouse ? 0.8 : 1.0
                        color: mouseAreaChange.pressed ? "#007AFF" : "#FFFFFF"

                        Image {
                            source: Qt.resolvedUrl("assets/change.png")
                            anchors.centerIn: parent
                            width: 20; height: 20
                            fillMode: Image.PreserveAspectFit
                            layer.enabled: true
                            layer.effect: MultiEffect {
                                brightness: mouseAreaChange.pressed ? 1.0 : 0.0
                                colorization: 1.0
                                colorizationColor: mouseAreaChange.pressed ? "#FFFFFF" : "#000000"
                            }
                        }

                        ToolTip {
                            visible: mouseAreaChange.containsMouse
                            text: "change picture"
                            delay: 50
                        }

                        MouseArea {
                            id: mouseAreaChange
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: imageFileDialog.open()
                        }
                    }
                }

                Item {
                    width: parent.width / 2
                    height: parent.height

                    Rectangle {
                        id: removeBtnContainer
                        width: 44; height: 44; radius: 22
                        anchors.centerIn: parent
                        opacity: mouseAreaRemove.containsMouse ? 0.8 : 1.0
                        color: mouseAreaRemove.pressed ? "#FF3B30" : "#FFFFFF"

                        Image {
                            source: Qt.resolvedUrl("assets/trash.png")
                            anchors.centerIn: parent
                            width: 20; height: 20
                            fillMode: Image.PreserveAspectFit
                            layer.enabled: true
                            layer.effect: MultiEffect {
                                brightness: mouseAreaRemove.pressed ? 1.0 : 0.0
                                colorization: 1.0
                                colorizationColor: mouseAreaRemove.pressed ? "#FFFFFF" : "#000000"
                            }
                        }

                        ToolTip {
                            visible: mouseAreaRemove.containsMouse
                            text: "remove picture"
                            delay: 50
                        }

                        MouseArea {
                            id: mouseAreaRemove
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: popupAddProduct.selectedImage = ""
                        }
                    }
                }
            }
        }
    }
    Item {
        id: add_Param
        x: 756
        y: 243 + (paramModel.count * 65)
        height: 24; width: 24

        visible: paramModel.count < 4

        Image {
            id: ellipse_2
            source: Qt.resolvedUrl("assets/ellipse_2.png")
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                if (paramModel.count < 4 && popupAddProduct.availableIds.length > 0) {

                    // 1. Urutkan keranjang dan ambil angka paling kecil
                    var sortedIds = popupAddProduct.availableIds.slice().sort()
                    var nextNum = sortedIds.shift()

                    // 2. Simpan sisa keranjang
                    popupAddProduct.availableIds = sortedIds

                    // 3. Tambahkan parameter ke layar dengan membawa ID tersebut
                    paramModel.append({
                        "inputText": "",
                        "paramName": "Parameter " + nextNum,
                        "slotId": nextNum,
                        "selectedUnit": "None",
                        "isCustomUnit": false
                    });
                }
            }
        }
        Shape {
            id: _vector_1

            x: 4.33
            y: 3.52

            height: 15.99
            width: 16

            ShapePath {
                id: _vector_1_ShapePath0

                fillColor: "#b8b8b8"
                fillRule: ShapePath.WindingFill
                joinStyle: ShapePath.MiterJoin
                strokeColor: "#00000000"
                strokeStyle: ShapePath.SolidLine
                strokeWidth: 1

                PathSvg {
                    id: _vector_1_ShapePath0_PathSvg0

                    path: "M 6.857142857142857 9.137142726353236 L 0 9.137142726353236 L 0 6.852857044764927 L 6.857142857142857 6.852857044764927 L 6.857142857142857 0 L 9.142857142857142 0 L 9.142857142857142 6.852857044764927 L 16 6.852857044764927 L 16 9.137142726353236 L 9.142857142857142 9.137142726353236 L 9.142857142857142 15.989999771118164 L 6.857142857142857 15.989999771118164 L 6.857142857142857 9.137142726353236 Z"
                }
            }
        }
    }
    Column {
        x: 20
        y: 248
        spacing: 15

        Repeater {
            model: paramModel

            delegate: Item {
                width: 760
                height: 50

                TextInput {
                    id: paramNameInput
                    width: 527
                    clip: true
                    text: model.paramName
                    font.family: "Inknut Antiqua"
                    font.pixelSize: 9
                    color: "#000000"
                    selectByMouse: true

                    opacity: hoverAreaLabel.containsMouse ? 0.8 : 1.0

                    property var suggestions: []

                    property string hoveredSuggestion: ""

                    onTextChanged: {
                        model.paramName = text

                        if (text.length > 0 && activeFocus) {
                            var allProducts = FileIO.readProducts();

                            var matches = [];
                            var seenParams = {};
                            var exactMatch = false;

                            for (var i = 0; i < allProducts.length; i++) {
                                var product = allProducts[i];
                                var params = product.parameters || [];

                                for (var j = 0; j < params.length; j++) {
                                    var pName = params[j].paramName;

                                    if (pName.toLowerCase().indexOf(text.toLowerCase()) === 0) {

                                        if (pName.toLowerCase() === text.toLowerCase()) {
                                            exactMatch = true;
                                        }

                                        if (!seenParams[pName]) {
                                            seenParams[pName] = true;
                                            matches.push({
                                                productName: product.name,
                                                paramName: pName
                                            });
                                        }
                                    }
                                }
                            }

                            suggestions = matches;

                            if (matches.length > 0 && !exactMatch) {
                                suggestionPopup.open();
                            } else {
                                suggestionPopup.close();
                            }
                        } else {
                            suggestionPopup.close();
                        }
                    }

                    Keys.onPressed: (event) => {
                        if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {

                            if (suggestionPopup.opened && hoveredSuggestion !== "") {
                                text = hoveredSuggestion;
                                model.paramName = hoveredSuggestion;
                            }

                            suggestionPopup.close();
                            focus = false;
                            event.accepted = true;
                        }
                    }

                    MouseArea {
                        id: hoverAreaLabel
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.NoButton
                    }

                    Popup {
                        id: suggestionPopup
                        y: 23
                        width: paramNameInput.width
                        height: Math.min(suggestionList.contentHeight + 2, 92)

                        padding: 1

                        closePolicy: Popup.CloseOnPressOutside | Popup.CloseOnEscape

                        background: Rectangle {
                            border.color: "#cccccc"
                            border.width: 1
                            radius: 4
                            color: "#ffffff"
                        }

                        contentItem: ListView {
                            id: suggestionList
                            implicitHeight: contentHeight
                            clip: true
                            model: paramNameInput.suggestions
                            boundsBehavior: Flickable.StopAtBounds

                            ScrollBar.vertical: ScrollBar {
                                active: true
                                policy: suggestionList.contentHeight > 90 ? ScrollBar.AlwaysOn : ScrollBar.AsNeeded
                            }

                            delegate: Rectangle {
                                width: suggestionList.width
                                height: 30
                                color: suggestionMouseArea.containsMouse ? "#f4f4f4" : "transparent"

                                Row {
                                    anchors.fill: parent
                                    anchors.leftMargin: 10

                                    anchors.rightMargin: suggestionList.ScrollBar.vertical.visible ? 12 : 0
                                    spacing: 8

                                    Text {
                                        text: modelData.paramName
                                        font.family: "Inknut Antiqua"
                                        font.pixelSize: 9
                                        color: "#000000"
                                        anchors.verticalCenter: parent.verticalCenter
                                    }

                                    Text {
                                        text: "(from " + modelData.productName + ")"
                                        font.family: "Inknut Antiqua"
                                        font.pixelSize: 9
                                        font.italic: true
                                        color: "#808080"
                                        anchors.verticalCenter: parent.verticalCenter
                                    }
                                }

                                MouseArea {
                                    id: suggestionMouseArea
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor

                                    // FITUR BARU: Update state item yang sedang disorot (hover)
                                    onContainsMouseChanged: {
                                        if (containsMouse) {
                                            paramNameInput.hoveredSuggestion = modelData.paramName;
                                        } else if (paramNameInput.hoveredSuggestion === modelData.paramName) {
                                            paramNameInput.hoveredSuggestion = "";
                                        }
                                    }

                                    onClicked: {
                                        paramNameInput.text = modelData.paramName;
                                        model.paramName = modelData.paramName;
                                        suggestionPopup.close();
                                        paramNameInput.focus = false;
                                    }
                                }
                            }
                        }
                    }
                }

                Rectangle {
                    y: 23
                    height: 27
                    width: 527
                    border.color: "#000000"
                    border.width: 1
                    radius: 5

                    TextField {
                        anchors.fill: parent

                        font.family: "Inknut Antiqua"
                        font.pixelSize: 11
                        leftPadding: 10
                        topPadding: 0
                        bottomPadding: 0
                        verticalAlignment: TextInput.AlignVCenter
                        background: null

                        text: model.inputText
                        onTextChanged: model.inputText = text
                    }
                }

                Text {
                    x: 546
                    text: "Unit"
                    font.family: "Inknut Antiqua"
                    font.pixelSize: 9
                    color: "#000000"
                }
                Shape {
                    x: 569
                    y: 6
                    height: 6.12
                    width: 4.90

                    ShapePath {
                        fillColor: "#00000000"
                        fillRule: ShapePath.WindingFill
                        strokeColor: "#d71f1f"
                        strokeWidth: 1

                        PathSvg {
                            path: "M 2.4507505893707275 3.0615234375 L 4.901501178741455 1.53076171875 M 2.4507505893707275 3.0615234375 L 2.4507505893707275 6.123046875 M 2.4507505893707275 3.0615234375 L 0 1.53076171875 M 2.4507505893707275 3.0615234375 L 4.901501178741455 4.59228515625 M 2.4507505893707275 0 L 2.4507505893707275 3.0615234375 M 2.4507505893707275 3.0615234375 L 0 4.59228515625"
                        }
                    }
                }
                Rectangle {
                    id: unitSelectBox
                    x: 546
                    y: 23
                    height: 27
                    width: 214
                    border.color: "#000000"
                    border.width: 1
                    radius: 5
                    color: "#ffffff"

                    TextInput {
                        id: unitInput
                        anchors.fill: parent
                        anchors.rightMargin: 30
                        leftPadding: 10
                        verticalAlignment: Text.AlignVCenter
                        clip: true

                        text: model.selectedUnit === "None" ? "- Select -" : model.selectedUnit

                        font.family: "Inknut Antiqua"
                        font.pixelSize: 11
                        color: model.selectedUnit === "None" ? "#26000000" : "#000000"

                        opacity: (model.isCustomUnit && unitInputMouseArea.containsMouse) ? 0.8 : 1.0

                        readOnly: !model.isCustomUnit
                        selectByMouse: model.isCustomUnit

                        onTextEdited: {
                            if (model.isCustomUnit) model.selectedUnit = text
                        }

                        MouseArea {
                            id: unitInputMouseArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor

                            acceptedButtons: model.isCustomUnit ? Qt.NoButton : Qt.LeftButton

                            onClicked: {
                                if (!model.isCustomUnit) unitPopup.open()
                            }
                        }
                    }

                    // Ikon Panah Dropdown
                    Shape {
                        x: 180; y: 11; height: 6.75; width: 14.82
                        ShapePath {
                            fillColor: "#bf000000"
                            strokeColor: "transparent"
                            PathSvg { path: "M 0 0 L 7.407 6.75 L 14.815 0 L 0 0 Z" }
                        }

                        MouseArea {
                            anchors.fill: parent
                            anchors.margins: -5 // Diperlebar sedikit agar panahnya gampang diklik
                            cursorShape: Qt.PointingHandCursor
                            onClicked: unitPopup.open()
                        }
                    }

                    Popup {
                        id: unitPopup
                        y: parent.height - 1
                        width: 214
                        height: 137
                        padding: 0
                        modal: true
                        dim: false
                        closePolicy: Popup.CloseOnPressOutside | Popup.CloseOnEscape

                        background: Rectangle { color: "transparent" }
                        contentItem: UnitList {
                            id: unitListComp
                            onUnitSelected: (unitName) => {
                                model.selectedUnit = unitName
                                model.isCustomUnit = (unitName === "Custom")
                                unitPopup.close()
                            }
                        }
                    }
                }
                Item {
                    x: 746
                    y: 5
                    height: 14
                    width: 14

                    Image {
                        anchors.fill: parent
                        source: Qt.resolvedUrl("assets/ellipse_8.png")
                    }

                    Rectangle {
                        width: 8
                        height: 1.5
                        color: "#f4f4f4"
                        anchors.centerIn: parent
                        radius: 1
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            var removedId = model.slotId;

                            var currentIds = popupAddProduct.availableIds.slice();
                            currentIds.push(removedId);
                            popupAddProduct.availableIds = currentIds.sort();

                            paramModel.remove(index)
                        }
                    }
                }
            }
        }
    }
    Item {
        id: name_Col

        x: 313
        y: 41

        height: 50
        width: 467

        Text {
            id: nameLabel
            text: "Name"
            font.family: "Inknut Antiqua"; font.pixelSize: 9
            color: "#000000"
        }
        Shape {
            id: _vector_2

            x: 29
            y: 6

            height: 6.12
            width: 4.90

            ShapePath {
                id: _vector_2_ShapePath0

                fillColor: "#00000000"
                fillRule: ShapePath.WindingFill
                strokeColor: "#d71f1f"
                strokeWidth: 1

                PathSvg {
                    id: _vector_2_ShapePath0_PathSvg0

                    path: "M 2.4507505893707275 3.0615234375 L 4.901501178741455 1.53076171875 M 2.4507505893707275 3.0615234375 L 2.4507505893707275 6.123046875 M 2.4507505893707275 3.0615234375 L 0 1.53076171875 M 2.4507505893707275 3.0615234375 L 4.901501178741455 4.59228515625 M 2.4507505893707275 0 L 2.4507505893707275 3.0615234375 M 2.4507505893707275 3.0615234375 L 0 4.59228515625"
                }
            }
        }
        TextField {
            id: nameInput
            y: 23
            width: 467; height: 27

            font.family: "Inknut Antiqua"
            font.pixelSize: 11

            topPadding: 0
            bottomPadding: 0
            verticalAlignment: TextInput.AlignVCenter

            placeholderText: "e.g. Milk"
            placeholderTextColor: "#80000000"
            leftPadding: 10

            selectByMouse: true
            clip: true

            background: Rectangle {
                border.color: "#000000"
                border.width: 1
                radius: 5
                color: "#ffffff"
            }
        }
    }
    Item {
        id: price_Col

        x: 313
        y: 99

        height: 50
        width: 233

        Text {
            id: priceLabel
            text: "Price"
            font.family: "Inknut Antiqua"; font.pixelSize: 9
            color: "#000000"
        }
        Shape {
            id: _vector_3

            x: 27
            y: 6

            height: 6.12
            width: 4.90

            ShapePath {
                id: _vector_3_ShapePath0

                fillColor: "#00000000"
                fillRule: ShapePath.WindingFill
                strokeColor: "#d71f1f"
                strokeWidth: 1

                PathSvg {
                    id: _vector_3_ShapePath0_PathSvg0

                    path: "M 2.4507505893707275 3.0615234375 L 4.901501178741455 1.53076171875 M 2.4507505893707275 3.0615234375 L 2.4507505893707275 6.123046875 M 2.4507505893707275 3.0615234375 L 0 1.53076171875 M 2.4507505893707275 3.0615234375 L 4.901501178741455 4.592285046692915 M 2.4507505893707275 0 L 2.4507505893707275 3.0615234375 M 2.4507505893707275 3.0615234375 L 0 4.592285046692915"
                }
            }
        }
        TextField {
            id: priceInput
            y: 23
            width: 233; height: 27
            font.family: "Inknut Antiqua"
            font.pixelSize: 11

            verticalAlignment: TextInput.AlignVCenter
            topPadding: 0; bottomPadding: 0
            leftPadding: 10

            placeholderText: popupAddProduct.currentCurrency === "IDR" ? "e.g. 15000" : "e.g. 10.00"
            placeholderTextColor: "#80000000"

            inputMethodHints: Qt.ImhDigitsOnly

            selectByMouse: true
            clip: true

            background: Rectangle {
                border.color: "#000000"
                border.width: 1
                radius: 5
                color: "#ffffff"
            }
        }
    }
    Item {
        id: desc_Col

        x: 313
        y: 157

        height: 76
        width: 467

        Text {
            id: descLabel
            text: "Description"
            font.family: "Inknut Antiqua"; font.pixelSize: 9
            color: "#000000"
        }
        ScrollView {
            id: descScroll
            y: 23
            width: 467; height: 53
            clip: true

            TextArea {
                id: descInput
                font.family: "Inknut Antiqua"
                font.pixelSize: 11

                // Placeholder teks penjelasan
                placeholderText: "e.g. Fresh milk from local farm with high calcium"
                placeholderTextColor: "#80000000"

                leftPadding: 10
                topPadding: 0
                bottomPadding: 0

                wrapMode: TextEdit.Wrap // Teks otomatis pindah baris
                selectByMouse: true

                background: Rectangle {
                    border.color: "#000000"
                    border.width: 1
                    radius: 5
                    color: "#ffffff"
                }
            }
        }
    }
    property string currentCurrency: "IDR"
    Item {
        id: currency_Col

        x: 566
        y: 99

        height: 50
        width: 214

        Rectangle {
            id: frame_3

            y: 23

            height: 27
            width: 214

            border.color: "#000000"
            border.width: 1
            color: "#ffffff"
            radius: 5
            Text {
                id: select_
                x: 10; y: 0; height: parent.height; width: 47
                leftPadding: 0
                color: "#000000"
                font.family: "Inknut Antiqua";
                font.pixelSize: 11
                text: popupAddProduct.currentCurrency
                verticalAlignment: Text.AlignVCenter
            }
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: currencyPopup.open()
            }
            Shape {
                id: _vector_4

                x: 180
                y: 11

                height: 6.75
                width: 14.82

                ShapePath {
                    id: _vector_4_ShapePath0

                    fillColor: "#bf000000"
                    fillRule: ShapePath.WindingFill
                    joinStyle: ShapePath.MiterJoin
                    strokeColor: "#00000000"
                    strokeStyle: ShapePath.SolidLine
                    strokeWidth: 1

                    PathSvg {
                        id: _vector_4_ShapePath0_PathSvg0

                        path: "M 0 0 L 7.4076924324035645 6.75 L 14.815384864807129 0 L 0 0 Z"
                    }
                }
            }
        }
        Popup {
            id: currencyPopup
            y: frame_3.y + frame_3.height - 1
            x: frame_3.x
            width: 214; height: 81 // Kembali ke ukuran aslinya yang sejajar!
            padding: 0
            modal: true
            dim: false
            closePolicy: Popup.CloseOnPressOutside | Popup.CloseOnEscape

            background: Rectangle { color: "transparent" }
            contentItem: CurrencyList {
                id: listComp
                onCurrencySelected: (code) => {
                    popupAddProduct.currentCurrency = code
                    currencyPopup.close()
                }
            }
        }
        Text {
            id: currencyLabel
            height: 23; width: 48
            text: "Currency"
            font.family: "Inknut Antiqua"; font.pixelSize: 9
            color: "#000000"
        }
        Shape {
            id: _vector_5

            x: 47
            y: 6

            height: 6.12
            width: 4.90

            ShapePath {
                id: _vector_5_ShapePath0

                fillColor: "#00000000"
                fillRule: ShapePath.WindingFill
                strokeColor: "#d71f1f"
                strokeWidth: 1

                PathSvg {
                    id: _vector_5_ShapePath0_PathSvg0

                    path: "M 2.4507505893707275 3.0615234375 L 4.901501178741455 1.53076171875 M 2.4507505893707275 3.0615234375 L 2.4507505893707275 6.123046875 M 2.4507505893707275 3.0615234375 L 0 1.53076171875 M 2.4507505893707275 3.0615234375 L 4.901501178741455 4.59228515625 M 2.4507505893707275 0 L 2.4507505893707275 3.0615234375 M 2.4507505893707275 3.0615234375 L 0 4.59228515625"
                }
            }
        }
    }
    FinishButton {
        id: finishButton

        x: 700
        y: 14

        width: 80
        height: 25

        property_2: btnMouseArea.pressed ? FinishButton.Property_1.Property_1_Variant3 :
                    btnMouseArea.containsMouse ? FinishButton.Property_1.Property_1_Variant2 :
                    FinishButton.Property_1.Property_1_Default

        MouseArea {
            id: btnMouseArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor

            onClicked: {
                popupAddProduct.saveData()
            }
        }
    }
}