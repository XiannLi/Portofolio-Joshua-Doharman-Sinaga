#include <QGuiApplication>
#include <QQuickStyle>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "jsonfileio.h"
#include "Compare.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    qmlRegisterType<Compare>("CheckMate", 1, 0, "CompareBackend");

    QQuickStyle::setStyle("Basic");
    QQmlApplicationEngine engine;

    JsonFileIO jsonIO;
    engine.rootContext()->setContextProperty("FileIO", &jsonIO);

    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.loadFromModule("CheckMate", "Main");

    return QCoreApplication::exec();
}
