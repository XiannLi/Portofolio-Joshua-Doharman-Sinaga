import QtQuick
import QtQuick.Controls
import QtQuick.Effects
import QtQuick.Shapes
import CheckMate

Rectangle {
    id: dashboard
    anchors.fill: parent
    color: "#fdfcfa"

    ListModel { id: productModel }

    function refreshData() {
        productModel.clear()
        var data = FileIO.readProducts()
        if (data) {
            for(var i = 0; i < data.length; i++) {
                productModel.append(data[i])
            }
        }
    }

    Component.onCompleted: refreshData()

    Sidebar {
        id: side_bar
        activeMenu: "dashboard"
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    Item {
        id: mainArea
        anchors.left: side_bar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom

        Item {
            id: headerGroup
            anchors.top: parent.top
            anchors.topMargin: 60
            anchors.left: parent.left
            anchors.leftMargin: 47.5
            height: 70
            width: 575

            Image {
                id: headerBg
                anchors.fill: parent
                source: productModel.count === 0 ? Qt.resolvedUrl("assets/rectangle_10.png") :
                                                   productModel.count === 1 ? Qt.resolvedUrl("assets/rectangle_30.png") :
                                                                              Qt.resolvedUrl("assets/rectangle_32.png")
            }

            Text {
                anchors.centerIn: parent
                color: "#000000"
                font.family: "Inknut Antiqua"
                font.pixelSize: 20
                text: productModel.count === 0 ? "Add your first product to start comparing!" :
                                                 productModel.count === 1 ? "Add your second product to start comparing!" :
                                                                            "You can start comparing now!"
            }
        }

        Row {
            anchors.right: parent.right
            anchors.rightMargin: 40
            anchors.top: parent.top
            anchors.topMargin: 67
            spacing: 15

            DeleteAllButton_1 {
                width: 110; height: 58
                visible: productModel.count > 0

                z: 10

                property_2: delMouseArea.pressed ? DeleteAllButton_1.Property_1.Property_1_Variant3 :
                                                   delMouseArea.containsMouse ? DeleteAllButton_1.Property_1.Property_1_Variant2 :
                                                                                DeleteAllButton_1.Property_1.Property_1_Default

                MouseArea {
                    id: delMouseArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor

                    onClicked: {
                        FileIO.clearAllProducts();
                        dashboard.refreshData();
                    }
                }
            }
            CompareButton_1 {
                width: 100; height: 58

                // PERBAIKAN: Logika state dikembalikan agar merespons hover dan klik secara dinamis
                property_2: productModel.count < 2 ? CompareButton_1.Property_1.Property_1_Default :
                                                     compMouseArea.pressed ? CompareButton_1.Property_1.Property_1_Variant4 :
                                                                             compMouseArea.containsMouse ? CompareButton_1.Property_1.Property_1_Variant3 :
                                                                                                           CompareButton_1.Property_1.Property_1_Variant2

                MouseArea {
                    id: compMouseArea // ID ditambahkan untuk ditangkap oleh property_2
                    anchors.fill: parent
                    hoverEnabled: true // PERBAIKAN: Menyalakan sensor hover
                    cursorShape: productModel.count >= 2 ? Qt.PointingHandCursor : Qt.ArrowCursor

                    onClicked: {
                        if (productModel.count >= 2) {
                            compareNotePopup.contentItem.buildParameterList(productModel)
                            compareNotePopup.open()
                        }
                    }
                }
            }
        }

        // --- GRID PRODUK OTOMATIS DENGAN SCROLL ---
        ScrollView {
            id: productScroll
            anchors.top: headerGroup.bottom
            anchors.bottom: parent.bottom
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.topMargin: 40

            contentWidth: width
            clip: true

            Grid {
                id: productGrid
                anchors.left: parent.left
                anchors.leftMargin: 47.5
                columns: 4
                spacing: 50

                Repeater {
                    model: productModel
                    delegate: Item {
                        width: 230
                        height: 300

                        ProductCard {
                            id: card
                            width: 230

                            productName: model.name
                            productPrice: model.price.toString()
                            productCurrency: model.currency
                            productDesc: model.description
                            productImage: model.image

                            productParams: model.parameters || []

                            onEditRequested: {
                                var currentData = {
                                    "image": model.image,
                                    "name": model.name,
                                    "price": model.price,
                                    "currency": model.currency,
                                    "description": model.description,
                                    "parameters": model.parameters
                                }

                                addProductPopup.contentItem.loadDataForEdit(currentData, index)

                                addProductPopup.open()
                            }
                        }

                        // 1. Ikon Minus (Hapus Satuan)
                        Image {
                            anchors.top: card.bottom
                            anchors.topMargin: 15
                            anchors.horizontalCenter: card.horizontalCenter
                            source: Qt.resolvedUrl("assets/_vector.png")

                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    FileIO.removeProduct(index)
                                    dashboard.refreshData()
                                }
                            }
                        }

                        // 2. TOMBOL HAPUS 1 BARIS
                        Rectangle {
                            visible: (index % 4 === 3)

                            anchors.verticalCenter: card.verticalCenter

                            anchors.left: card.right
                            anchors.leftMargin: ((mainArea.width - (productGrid.anchors.leftMargin + productGrid.width)) / 2) - (width / 2)

                            width: 38; height: 32
                            radius: 8

                            color: rowDelMouse.pressed ? "#AE4750" : "#D08B91"
                            opacity: rowDelMouse.pressed ? 1.0 : (rowDelMouse.containsMouse ? 0.8 : 1.0)

                            Row {
                                anchors.centerIn: parent
                                spacing: 4

                                Shape {
                                    width: 12; height: 12
                                    anchors.verticalCenter: parent.verticalCenter
                                    ShapePath {
                                        fillColor: "transparent"

                                        strokeColor: {
                                            var baseColor = rowDelMouse.pressed ? "#ffffff" : "#000000";
                                            var alpha = rowDelMouse.pressed ? 1.0 : (rowDelMouse.containsMouse ? 0.8 : 1.0);
                                            return Qt.rgba(rowDelMouse.pressed ? 1 : 0,
                                                           rowDelMouse.pressed ? 1 : 0,
                                                           rowDelMouse.pressed ? 1 : 0,
                                                           alpha);
                                        }

                                        strokeWidth: 1
                                        joinStyle: ShapePath.RoundJoin
                                        PathSvg { path: "M 12 4 L 5 4 L 5 1 L 0 6 L 5 11 L 5 8 L 12 8 Z" }
                                    }
                                }

                                Image {
                                    width: 12; height: 12
                                    anchors.verticalCenter: parent.verticalCenter
                                    source: Qt.resolvedUrl("assets/trash.png")
                                    fillMode: Image.PreserveAspectFit
                                    layer.enabled: true
                                    layer.effect: MultiEffect {
                                        brightness: rowDelMouse.pressed ? 1.0 : 0.0
                                        colorization: 1.0
                                        colorizationColor: rowDelMouse.pressed ? "#ffffff" : "#000000"
                                    }
                                }
                            }

                            ToolTip {
                                visible: rowDelMouse.containsMouse
                                text: "Delete this row"
                            }

                            MouseArea {
                                id: rowDelMouse
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                hoverEnabled: true
                                onClicked: {
                                    var startIndex = Math.floor(index / 4) * 4;
                                    for (var i = 3; i >= 0; i--) {
                                        FileIO.removeProduct(startIndex + i);
                                    }
                                    dashboard.refreshData();
                                }
                            }
                        }
                    }
                }

                // 3. Tombol "+"
                AddProductButton {
                    id: addBtn
                    width: 230; height: 180

                    visible: productModel.count < 12

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: addProductPopup.open()
                    }
                }
            }
        }
    }

    // --- POPUP INPUT PRODUK ---
    Popup {
        id: addProductPopup
        width: 800; height: 533
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2
        modal: true; focus: true
        dim: true

        padding: 0
        background: null

        Overlay.modal: Rectangle {
            color: Qt.rgba(0, 0, 0, 0.5)
        }

        contentItem: PopupAddProduct {
            radius: 10

            onProductSaved: {
                addProductPopup.close()
                dashboard.refreshData()
            }
        }
    }
    // --- POPUP COMPARE NOTE ---
    Popup {
        id: compareNotePopup
        width: contentItem.width; height: contentItem.height
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        modal: true; focus: true; dim: true
        padding: 0
        background: null
        closePolicy: Popup.CloseOnPressOutside | Popup.CloseOnEscape

        Overlay.modal: Rectangle { color: Qt.rgba(0, 0, 0, 0.5) }

        contentItem: CompareNote {
            onCloseRequested: compareNotePopup.close()
        }
    }
}