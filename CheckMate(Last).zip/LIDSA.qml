import QtQuick

Rectangle {
    enum Property_1 { Property_1_Default, Property_1_Variant2, Property_1_Variant3, Property_1_Variant4}

    id: lIDSA

    property alias lIDSA_1Opacity: lIDSA_1.opacity
    property alias lIDSA_1Width: lIDSA_1.width
    property alias lIDSA_1WrapMode: lIDSA_1.wrapMode
    property alias rectangle_22BorderColor: rectangle_22.border.color
    property alias rectangle_22BorderWidth: rectangle_22.border.width
    property alias rectangle_22Radius: rectangle_22.radius

    property string first: "LIDSA"
    property int property_2: LIDSA.Property_1.Property_1_Default

    height: 27
    width: 214

    color: "transparent"

    states: [
        State {
            name: "Property 1=Default"
            when: lIDSA.property_2 === LIDSA.Property_1.Property_1_Default
    
            PropertyChanges {
                y: -0.82
    
                target: rectangle_22
            }
            PropertyChanges {
                color: "#ffffff"
                target: rectangle_22
            }
            PropertyChanges {
                target: rectangle_22
                topLeftRadius: 5
            }
            PropertyChanges {
                target: rectangle_22
                topRightRadius: 5
            }
            PropertyChanges {
                border.width: 0
                target: rectangle_22
            }
            PropertyChanges {
                border.color: "white"
                target: rectangle_22
            }
            PropertyChanges {
                radius: 0
                target: rectangle_22
            }
            PropertyChanges {
                width: 35
    
                target: lIDSA_1
            }
            PropertyChanges {
                font.weight: Font.Normal
                target: lIDSA_1
            }
            PropertyChanges {
                target: lIDSA_1
                wrapMode: Text.NoWrap
            }
        },
        State {
            name: "Property 1=Variant2"
            when: lIDSA.property_2 === LIDSA.Property_1.Property_1_Variant2
    
            PropertyChanges {
                y: 0
    
                target: rectangle_22
            }
            PropertyChanges {
                color: "#efefef"
                target: rectangle_22
            }
            PropertyChanges {
                target: rectangle_22
                topLeftRadius: 5
            }
            PropertyChanges {
                target: rectangle_22
                topRightRadius: 5
            }
            PropertyChanges {
                border.width: 0
                target: rectangle_22
            }
            PropertyChanges {
                border.color: "white"
                target: rectangle_22
            }
            PropertyChanges {
                radius: 0
                target: rectangle_22
            }
            PropertyChanges {
                width: 35
    
                target: lIDSA_1
            }
            PropertyChanges {
                font.weight: Font.Normal
                target: lIDSA_1
            }
            PropertyChanges {
                target: lIDSA_1
                wrapMode: Text.NoWrap
            }
        },
        State {
            name: "Property 1=Variant3"
            when: lIDSA.property_2 === LIDSA.Property_1.Property_1_Variant3
    
            PropertyChanges {
                y: 0
    
                target: rectangle_22
            }
            PropertyChanges {
                color: "#efefef"
                target: rectangle_22
            }
            PropertyChanges {
                target: rectangle_22
                topLeftRadius: 5
            }
            PropertyChanges {
                target: rectangle_22
                topRightRadius: 5
            }
            PropertyChanges {
                border.width: 0
                target: rectangle_22
            }
            PropertyChanges {
                border.color: "white"
                target: rectangle_22
            }
            PropertyChanges {
                radius: 0
                target: rectangle_22
            }
            PropertyChanges {
                width: 36
    
                target: lIDSA_1
            }
            PropertyChanges {
                font.weight: Font.Bold
                target: lIDSA_1
            }
            PropertyChanges {
                target: lIDSA_1
                wrapMode: Text.NoWrap
            }
        },
        State {
            name: "Property 1=Variant4"
            when: lIDSA.property_2 === LIDSA.Property_1.Property_1_Variant4
    
            PropertyChanges {
                y: 0
    
                target: rectangle_22
            }
            PropertyChanges {
                color: "#ffffff"
                target: rectangle_22
            }
            PropertyChanges {
                target: rectangle_22
                topLeftRadius: 0
            }
            PropertyChanges {
                target: rectangle_22
                topRightRadius: 0
            }
            PropertyChanges {
                border.width: 0.25
                target: rectangle_22
            }
            PropertyChanges {
                border.color: "#000000"
                target: rectangle_22
            }
            PropertyChanges {
                radius: 5
                target: rectangle_22
            }
            PropertyChanges {
                width: 35
    
                target: lIDSA_1
            }
            PropertyChanges {
                font.weight: Font.Normal
                target: lIDSA_1
            }
            PropertyChanges {
                target: lIDSA_1
                wrapMode: Text.Wrap
            }
        }
    ]

    Rectangle {
        id: rectangle_22

        y: -0.82

        height: 27
        width: 214

        border.color: "white"
        border.width: 0
        color: "#ffffff"
        radius: 0
        topLeftRadius: 5
        topRightRadius: 5
    }
    Text {
        id: lIDSA_1

        x: 12
        y: 2

        height: 23
        width: 35

        color: "#000000"
        font.family: "Inknut Antiqua"
        font.pixelSize: 9
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignLeft
        opacity: 1
        text: lIDSA.first
        verticalAlignment: Text.AlignTop
        wrapMode: Text.NoWrap
    }
}