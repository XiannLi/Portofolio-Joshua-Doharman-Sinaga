import QtQuick

Rectangle {
    enum Property_1 { Property_1_Default, Property_1_Variant2, Property_1_Variant3}

    id: deleteAllButton

    property int property_2: DeleteAllButton_1.Property_1.Property_1_Default

    height: 58
    width: 110

    color: "transparent"
    opacity: 1

    states: [
        State {
            name: "Property 1=Default"
            when: deleteAllButton.property_2 === DeleteAllButton_1.Property_1.Property_1_Default
    
            PropertyChanges {
                opacity: 1
                target: deleteAllButton
            }
            PropertyChanges {
                source: Qt.resolvedUrl("assets/rectangle_14.png")
                target: rectangle_5
            }
            PropertyChanges {
                color: "#000000"
                target: delete_All
            }
        },
        State {
            name: "Property 1=Variant2"
            when: deleteAllButton.property_2 === DeleteAllButton_1.Property_1.Property_1_Variant2
    
            PropertyChanges {
                opacity: 0.80
                target: deleteAllButton
            }
            PropertyChanges {
                source: Qt.resolvedUrl("assets/rectangle_28.png")
                target: rectangle_5
            }
            PropertyChanges {
                color: "#000000"
                target: delete_All
            }
        },
        State {
            name: "Property 1=Variant3"
            when: deleteAllButton.property_2 === DeleteAllButton_1.Property_1.Property_1_Variant3
    
            PropertyChanges {
                opacity: 1
                target: deleteAllButton
            }
            PropertyChanges {
                source: Qt.resolvedUrl("assets/rectangle_27.png")
                target: rectangle_5
            }
            PropertyChanges {
                color: "#f5f5f5"
                target: delete_All
            }
        }
    ]

    Image {
        id: rectangle_5

        x: -2
        y: -2

        source: Qt.resolvedUrl("assets/rectangle_14.png")
    }
    Text {
        id: delete_All

        x: 13
        y: 8.44

        height: 41.13
        width: 84

        color: "#000000"
        font.family: "Inknut Antiqua"
        font.pixelSize: 15
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignLeft
        text: "Delete All"
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignTop
        wrapMode: Text.Wrap
    }
}