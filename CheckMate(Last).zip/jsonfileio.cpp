#include "jsonfileio.h"
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QStandardPaths>
#include <QDir>
#include <QDebug>

JsonFileIO::JsonFileIO(QObject *parent) : QObject(parent) {}

void JsonFileIO::saveProduct(const QVariantMap &productData) {
    // 1. Ambil path otomatis ke folder Documents milik user Windows
    QString dirPath = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/CheckMate/Database";
    QDir dir(dirPath);

    // 2. Jika folder CheckMateData belum ada di Documents, buat otomatis!
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    QString filePath = dirPath + "/ProductData.json";

    QJsonArray jsonArray;
    QFile file(filePath);

    // 3. Cek file lama untuk ditambah (append)
    if (file.exists() && file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QByteArray fileData = file.readAll();
        QJsonDocument doc = QJsonDocument::fromJson(fileData);
        if (doc.isArray()) {
            jsonArray = doc.array();
        }
        file.close();
    }

    // 4. Masukkan data baru
    jsonArray.append(QJsonObject::fromVariantMap(productData));

    // 5. Tulis file JSON
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QJsonDocument newDoc(jsonArray);
        file.write(newDoc.toJson(QJsonDocument::Indented));
        file.close();
        qDebug() << "Data berhasil disimpan di " << filePath;
    } else {
        qDebug() << "Gagal membuka file:" << filePath;
    }
}
QVariantList JsonFileIO::readProducts() {
    QString filePath = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/CheckMate/Database/ProductData.json";
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
        file.close();
        return doc.toVariant().toList();
    }
    return QVariantList(); // Kembalikan list kosong jika file belum ada
}
void JsonFileIO::removeProduct(int index) {
    QString filePath = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/CheckMate/Database/ProductData.json";
    QFile file(filePath);

    // Baca file yang ada
    if (file.exists() && file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QByteArray fileData = file.readAll();
        QJsonDocument doc = QJsonDocument::fromJson(fileData);
        file.close();

        if (doc.isArray()) {
            QJsonArray jsonArray = doc.array();
            // Validasi apakah index yang mau dihapus tersedia
            if (index >= 0 && index < jsonArray.size()) {
                jsonArray.removeAt(index); // Eksekusi hapus di array

                // Tulis ulang JSON tanpa produk tersebut
                if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
                    QJsonDocument newDoc(jsonArray);
                    file.write(newDoc.toJson(QJsonDocument::Indented));
                    file.close();
                }
            }
        }
    }
}
void JsonFileIO::clearAllProducts() {
    QString filePath = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/CheckMate/Database/ProductData.json";
    QFile file(filePath);

    // Langsung timpa file dengan array kosong
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QJsonArray emptyArray;
        QJsonDocument newDoc(emptyArray);
        file.write(newDoc.toJson(QJsonDocument::Indented));
        file.close();
    }
}