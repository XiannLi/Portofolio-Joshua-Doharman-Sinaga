import QtQuick
import QtQuick.Layouts

Rectangle {
    id: first
    anchors.fill: parent
    color: "#fdfcfa"

    ColumnLayout {
        anchors.centerIn: parent
        spacing: 0

        Image {
            id: checkMate_Logo
            source: Qt.resolvedUrl("assets/checkMate_Logo_1.png")
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: -185
            opacity: 0
        }

        Text {
            id: slogan
            Layout.topMargin: -200
            Layout.alignment: Qt.AlignHCenter

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignHCenter
            opacity: 0
            text: "Check Every Products, Trust CheckMate"
            textFormat: Text.PlainText
        }
    }

    SequentialAnimation {
        // Menjalankan animasi secara otomatis saat komponen dimuat
        running: true

        // Menampilkan logo dengan animasi Ease In selama 2.5 detik
        NumberAnimation {
            target: checkMate_Logo
            property: "opacity"
            to: 1.0
            duration: 2500
            easing.type: Easing.InQuad
        }

        // Memberi jeda waktu selama 1 detik
        PauseAnimation {
            duration: 1000
        }

        // Menampilkan tulisan dengan animasi Ease In selama 2.5 detik
        NumberAnimation {
            target: slogan
            property: "opacity"
            to: 1.0
            duration: 2500
            easing.type: Easing.InQuad
        }
    }
}