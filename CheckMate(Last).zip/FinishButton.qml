import QtQuick

Item {
    enum Property_1 { Property_1_Default, Property_1_Variant2, Property_1_Variant3 }

    id: finishButton

    property int property_2: FinishButton.Property_1.Property_1_Default

    width: 80
    height: 25

    Rectangle {
        anchors.fill: parent
        radius: 5

        color: finishButton.property_2 === FinishButton.Property_1.Property_1_Variant3 ? "#506568" : "#8BA1A5"

        opacity: finishButton.property_2 === FinishButton.Property_1.Property_1_Variant2 ? 0.8 : 1.0

        Text {
            anchors.centerIn: parent
            text: "Finish"
            color: "#ffffff"
            font.family: "Inknut Antiqua"
            font.pixelSize: 10
        }

        Behavior on color {
            ColorAnimation { duration: 100 }
        }

        Behavior on opacity {
            NumberAnimation { duration: 100 }
        }
    }
}