import QtQuick
import QtQuick.Controls

Rectangle {
    id: unitList

    // Tinggi ideal 137 (135 konten + 2 margin)
    height: 137
    width: 214
    border.color: "#000000"
    border.width: 1
    color: "transparent"
    radius: 5

    signal unitSelected(string unitName)

    readonly property var unitData: {
            // 1. Ritel & Barang Sehari-hari (FMCG) - Paling Sering Digunakan
            "Packaging & Quantity": ["Piece (pcs)", "Pair", "Dozen", "Set", "Pack", "Box", "Bottle", "Tube", "Roll"],
            "Weight & Mass": ["Atomic Mass Unit (u)", "Microgram (µg)", "Milligram (mg)", "Carat (ct)", "Gram (g)", "Ounce (oz)", "Pound (lb)", "Stone (st)", "Kilogram (kg)", "Short Ton (ton)", "Long Ton (ton)", "Metric Ton (t)"],
            "Volume": ["Cubic Millimeter (mm³)", "Imperial Tea Spoon", "US Tea Spoon", "Imperial Table Spoon", "US Table Spoon", "Milliliter (mL)", "US Fluid Ounce (fl oz)", "US Cup", "Liter (L)", "US Gallon (gal)", "Cubic Meter (m³)"],
            "Length": ["Nanometer (nm)", "Micrometer (μm)", "Millimeter (mm)", "Centimeter (cm)", "Inch (in)", "Foot (ft)", "Yard (yd)", "Meter (m)", "Kilometer (km)", "Mile (mi)", "Nautical Mile (nmi)"],
            "Area": ["Square Millimeter (mm²)", "Square Centimeter (cm²)", "Square Inch (in²)", "Square Foot (ft²)", "Square Yard (yd²)", "Square Meter (m²)", "Acre", "Hectare (ha)", "Square Kilometer (km²)", "Square Mile (mi²)"],

            // 2. Elektronik & Komputasi Konsumen
            "Data Storage": ["Bit (b)", "Nibble", "Byte (B)", "Kilobyte (KB)", "Megabyte (MB)", "Gigabyte (GB)", "Terabyte (TB)", "Petabyte (PB)", "Exabyte (EB)"],
            "Resolution & Density": ["Pixels per Inch (PPI)", "Dots per Inch (DPI)"],
            "Data Transfer Rate": ["Bit/second (bps)", "Kilobit/second (Kbps)", "Megabit/second (Mbps)", "Gigabit/second (Gbps)", "Byte/second (B/s)", "Kilobyte/second (KB/s)", "Megabyte/second (MB/s)", "Gigabyte/second (GB/s)", "Terabyte/second (TB/s)"],

            // 3. Kelistrikan & Peralatan Rumah Tangga (Home Appliances)
            "Power": ["Nanowatt (nW)", "Microwatt (µW)", "Milliwatt (mW)", "Watt (W)", "Deciwatt (dW)", "Horsepower (hp)", "Kilowatt (kW)", "Megawatt (MW)", "Gigawatt (GW)"],
            "Voltage": ["Nanovolt (nV)", "Microvolt (µV)", "Millivolt (mV)", "Volt (V)", "Decivolt (dV)", "Kilovolt (kV)", "Megavolt (MV)"],
            "Electric Current": ["Nanoampere (nA)", "Microampere (µA)", "Milliampere (mA)", "Centiampere (cA)", "Deciampere (dA)", "Ampere (A)", "Decaampere (daA)", "Kiloampere (kA)"],
            "Energy": ["Electronvolt (eV)", "Erg", "Joule (J)", "Kilojoule (kJ)", "Calorie (cal)", "Kilocalorie (kcal)", "Watt-hour (Wh)", "British Thermal Unit (BTU)", "Kilowatt-hour (kWh)", "Megajoule (MJ)", "Gigajoule (GJ)", "Barrel of Oil Equivalent (boe)"],
            "Temperature": ["Kelvin (K)", "Rankine (°R)", "Celsius (°C)", "Fahrenheit (°F)", "Reaumur (°Ré)", "Wedgwood", "Gas Mark"],

            // 4. Fisika Dasar, Otomotif & Mekanik
            "Time": ["Nanosecond (ns)", "Microsecond (µs)", "Millisecond (ms)", "Second (s)", "Minute (min)", "Hour (h)", "Day", "Week", "Month", "Year", "Decade", "Century"],
            "Speed": ["Millimeter/second (mm/s)", "Centimeter/second (cm/s)", "Foot/second (ft/s)", "Kilometer/hour (km/h)", "Mile/hour (mph)", "Knot (kn)", "Meter/second (m/s)", "Kilometer/second (km/s)", "Mile/second (mi/s)", "Mach"],
            "Torque": ["Newton-meter (Nm)", "Kilogram-meter (kg-m)", "Pound-foot (lb-ft)"],
            "Fuel Economy": ["Kilometer/Liter (km/L)", "Liter/100km", "Miles/Gallon (MPG)"],
            "Pressure": ["Micropascal (µPa)", "Pascal (Pa)", "Hectopascal (hPa)", "Kilopascal (kPa)", "PSI", "Bar", "Atmosphere (atm)", "Technical Atmosphere (at)", "Megapascal (MPa)", "Kilopound per Square Inch (ksi)", "Gigapascal (GPa)"],

            // 5. Spesifikasi Industri, Komponen Optik & Elektronika Lanjutan
            "Frequency": ["Millihertz (mHz)", "Hertz (Hz)", "Kilohertz (kHz)", "Megahertz (MHz)", "Gigahertz (GHz)", "Terahertz (THz)"],
            "Luminous Flux": ["Nanolumen (nlm)", "Microlumen (µlm)", "Millilumen (mlm)", "Lumen (lm)", "Candlepower (cp)", "Talbot", "Kilolumen (klm)", "Megalumen (Mlm)", "Gigalumen (Glm)"],
            "Illuminance & Luminance": ["Lux (lx)", "Nit (cd/m²)", "Foot-candle (fc)"],
            "Force": ["Nanonewton (nN)", "Micronewton (µN)", "Millinewton (mN)", "Newton (N)", "Pound-force (lbf)", "Kilopond (kp)", "Kilonewton (kN)", "Short Ton-force (stf)", "Long Ton-force (ltf)", "Meganewton (MN)"],
            "Resistance": ["Nanoohm (nΩ)", "Microohm (µΩ)", "Milliohm (mΩ)", "Ohm (Ω)", "Decaohm (daΩ)", "Kiloohm (kΩ)", "Megaohm (MΩ)", "Gigaohm (GΩ)", "Teraohm (TΩ)"],

            // 6. Kustomisasi Bebas
            "Custom": []
        }

    property bool inUnitMode: false
    property var fullList: []
    property int currentPage: 0
    property int itemsPerPage: 5
    property int totalPages: 1

    ListModel {
        id: displayModel
    }

    // FUNGSI ALOKASI SLOT DINAMIS
    function calculateSlots() {
        // Total slot yang tersedia adalah 5
        // Jika sedang di dalam Unit (inUnitMode), Header akan makan 1 slot. Sisa 4.
        var availableSlots = inUnitMode ? 4 : 5

        if (fullList.length <= availableSlots) {
            // Jika total item muat di sisa slot, tidak butuh Footer pagination
            itemsPerPage = availableSlots
            totalPages = 1
        } else {
            // Jika berlebih, Footer pagination akan makan 1 slot lagi
            itemsPerPage = availableSlots - 1
            totalPages = Math.ceil(fullList.length / itemsPerPage)
        }
    }

    function renderPage() {
        displayModel.clear()
        var start = currentPage * itemsPerPage
        var end = Math.min(start + itemsPerPage, fullList.length)

        for (var i = start; i < end; i++) {
            displayModel.append({ "itemName": fullList[i] })
        }
    }

    function loadCategories() {
        fullList = Object.keys(unitData)
        currentPage = 0
        inUnitMode = false
        calculateSlots()
        renderPage()
    }

    function loadUnits(category) {
        fullList = unitData[category]
        currentPage = 0
        inUnitMode = true
        calculateSlots()
        renderPage()
    }

    Component.onCompleted: loadCategories()

    Rectangle {
        anchors.fill: parent
        anchors.margins: 1
        color: "#ffffff"
        radius: 4
        clip: true

        // 1. HEADER - Tinggi diset tepat 27 (1 slot)
        Rectangle {
            id: headerArea
            width: parent.width
            height: inUnitMode ? 27 : 0
            color: "#f4f4f4"
            visible: inUnitMode
            clip: true
            anchors.top: parent.top

            Text {
                anchors.centerIn: parent
                text: "⬅ Back to Categories"
                font.family: "Inknut Antiqua"; font.pixelSize: 9
                color: "#d71f1f"
            }

            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: unitList.loadCategories()
            }

            Rectangle {
                width: parent.width; height: 1; color: "#e0e0e0"
                anchors.bottom: parent.bottom
            }
        }

        // 2. KONTEN ITEM
        Column {
            width: parent.width
            anchors.top: headerArea.bottom

            Repeater {
                model: displayModel

                delegate: Rectangle {
                    width: parent.width
                    height: 27 // Konsisten 1 slot
                    color: itemMA.containsMouse ? "#f5f5f5" : "transparent"

                    Text {
                        x: 12
                        anchors.verticalCenter: parent.verticalCenter
                        text: model.itemName
                        font.family: "Inknut Antiqua"; font.pixelSize: 9
                        color: "#000000"
                    }

                    MouseArea {
                        id: itemMA
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            if (!unitList.inUnitMode) {
                                var category = model.itemName
                                var subItems = unitList.unitData[category]

                                if (subItems.length === 0) {
                                    unitList.unitSelected(category)
                                } else {
                                    unitList.loadUnits(category)
                                }
                            } else {
                                unitList.unitSelected(model.itemName)
                                unitList.loadCategories()
                            }
                        }
                    }

                    Rectangle {
                        width: parent.width - 20
                        x: 10
                        height: 1
                        color: "#eeeeee"
                        anchors.bottom: parent.bottom
                        visible: index < displayModel.count - 1
                    }
                }
            }
        }

        // 3. FOOTER PAGINATION - Tinggi diset tepat 27 (1 slot)
        Rectangle {
            width: parent.width
            height: 27
            color: "#f9f9f9"
            anchors.bottom: parent.bottom
            visible: totalPages > 1

            Rectangle {
                width: parent.width; height: 1; color: "#e0e0e0"
                anchors.top: parent.top
            }

            Text {
                x: 15; anchors.verticalCenter: parent.verticalCenter
                text: "◀ Prev"
                font.family: "Inknut Antiqua"; font.pixelSize: 9
                color: currentPage > 0 ? "#007AFF" : "#aaaaaa"

                MouseArea {
                    anchors.fill: parent; anchors.margins: -5
                    cursorShape: currentPage > 0 ? Qt.PointingHandCursor : Qt.ArrowCursor
                    onClicked: {
                        if (currentPage > 0) {
                            currentPage--
                            renderPage()
                        }
                    }
                }
            }

            Text {
                anchors.centerIn: parent
                text: (currentPage + 1) + " / " + totalPages
                font.family: "Inknut Antiqua"; font.pixelSize: 8
                color: "#888888"
            }

            Text {
                x: parent.width - width - 15; anchors.verticalCenter: parent.verticalCenter
                text: "Next ▶"
                font.family: "Inknut Antiqua"; font.pixelSize: 9
                color: currentPage < totalPages - 1 ? "#007AFF" : "#aaaaaa"

                MouseArea {
                    anchors.fill: parent; anchors.margins: -5
                    cursorShape: currentPage < totalPages - 1 ? Qt.PointingHandCursor : Qt.ArrowCursor
                    onClicked: {
                        if (currentPage < totalPages - 1) {
                            currentPage++
                            renderPage()
                        }
                    }
                }
            }
        }
    }
}