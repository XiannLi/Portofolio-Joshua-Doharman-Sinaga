import QtQuick
import QtQuick.Shapes

Rectangle {
    enum Property_1 { Property_1_Default, Property_1_Variant2, Property_1_Variant3}

    id: dashboardButtonwT

    property int property_2: DashboardButtonwT_1.Property_1.Property_1_Default

    height: 70
    width: 240

    color: "transparent"
    opacity: 1

    states: [
        State {
            name: "Property 1=Default"
            when: dashboardButtonwT.property_2 === DashboardButtonwT_1.Property_1.Property_1_Default
    
            PropertyChanges {
                opacity: 1
                target: dashboardButtonwT
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                color: "#000000"
                target: dashboard
            }
        },
        State {
            name: "Property 1=Variant2"
            when: dashboardButtonwT.property_2 === DashboardButtonwT_1.Property_1.Property_1_Variant2
    
            PropertyChanges {
                opacity: 0.85
                target: dashboardButtonwT
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                color: "#000000"
                target: dashboard
            }
        },
        State {
            name: "Property 1=Variant3"
            when: dashboardButtonwT.property_2 === DashboardButtonwT_1.Property_1.Property_1_Variant3
    
            PropertyChanges {
                opacity: 1
                target: dashboardButtonwT
            }
            PropertyChanges {
                color: "#87b4c0"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#f3f3f7"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#f3f3f7"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: dashboard
            }
        }
    ]

    Rectangle {
        id: rectangle_1

        height: 70
        width: 240

        color: "#f3f3f7"
        radius: 15
    }
    Item {
        id: group

        x: 16
        y: 16

        height: 38
        width: 34

        Shape {
            id: _vector

            height: 38
            width: 34

            ShapePath {
                id: _vector_ShapePath0

                fillColor: "#00000000"
                fillRule: ShapePath.WindingFill
                strokeColor: "#000000"
                strokeWidth: 3

                PathSvg {
                    id: _vector_ShapePath0_PathSvg0

                    path: "M 4.532624781131744 38 C 2.029374837875366 38 0 35.931141851682824 0 33.37673657451171 L 0 14.795022987966192 C 0 13.391155623852892 0.6268754154443741 12.061176005811603 1.7000004053115845 11.185078373340593 L 14.167374610900879 1.0139006492197102 C 14.963948413729668 0.35858544430314965 15.965760983526707 9.37507260671642e-16 17 0 C 18.034239016473293 9.37507260671642e-16 19.036051586270332 0.35858544430314965 19.83262538909912 1.0139006492197102 L 32.297873735427856 11.185078373340593 C 33.373123697936535 12.061176005811603 34 13.391155623852892 34 14.795022987966192 L 34 33.37673657451171 C 34 35.931141851682824 31.970626175403595 38 29.467376232147217 38 L 4.532624781131744 38 Z"
                }
            }
        }
        Shape {
            id: _vector_1

            x: 11.69
            y: 22.17

            height: 15.83
            width: 10.63

            ShapePath {
                id: _vector_1_ShapePath0

                fillColor: "#00000000"
                fillRule: ShapePath.WindingFill
                strokeColor: "#000000"
                strokeWidth: 3

                PathSvg {
                    id: _vector_1_ShapePath0_PathSvg0

                    path: "M 0 15.833089828491211 L 0 4.222157287597656 C 0 3.102371511159572 0.4477674029767513 2.028450111429288 1.2447969913482666 1.2366420443766402 C 2.041826579719782 0.4448339773239923 3.1228298768401146 -3.750028987423853e-15 4.25 0 L 6.375 0 C 7.502170123159885 0 8.583173420280218 0.4448339773239923 9.380203008651733 1.2366420443766402 C 10.177232597023249 2.028450111429288 10.625 3.102371511159572 10.625 4.222157287597656 L 10.625 15.833089828491211"
                }
            }
        }
    }
    Text {
        id: dashboard

        x: 69
        y: 3

        height: 64
        width: 159

        color: "#000000"
        font.family: "Inknut Antiqua"
        font.pixelSize: 25
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignLeft
        text: "Dashboard"
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignTop
        wrapMode: Text.Wrap
    }
}