import QtQuick
import QtQuick.Shapes

Rectangle {
    enum Property_1 { Property_1_Default, Property_1_Variant2, Property_1_Variant3}

    id: helpButtonwT

    property int property_2: HelpButtonwT_1.Property_1.Property_1_Default

    height: 70
    width: 240

    color: "transparent"
    opacity: 1

    states: [
        State {
            name: "Property 1=Help"
            when: helpButtonwT.property_2 === HelpButtonwT_1.Property_1.Property_1_Default
    
            PropertyChanges {
                opacity: 1
                target: helpButtonwT
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                fillColor: "#000000"
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#00000000"
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                joinStyle: ShapePath.MiterJoin
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                strokeStyle: ShapePath.SolidLine
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                width: 84
    
                target: help
            }
            PropertyChanges {
                color: "#000000"
                target: help
            }
            PropertyChanges {
                target: help
                wrapMode: Text.Wrap
            }
        },
        State {
            name: "Property 1=Variant2"
            when: helpButtonwT.property_2 === HelpButtonwT_1.Property_1.Property_1_Variant2
    
            PropertyChanges {
                opacity: 0.85
                target: helpButtonwT
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                fillColor: "#000000"
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#00000000"
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                joinStyle: ShapePath.MiterJoin
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                strokeStyle: ShapePath.SolidLine
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                width: 84
    
                target: help
            }
            PropertyChanges {
                color: "#000000"
                target: help
            }
            PropertyChanges {
                target: help
                wrapMode: Text.Wrap
            }
        },
        State {
            name: "Property 1=Variant3"
            when: helpButtonwT.property_2 === HelpButtonwT_1.Property_1.Property_1_Variant3
    
            PropertyChanges {
                opacity: 1
                target: helpButtonwT
            }
            PropertyChanges {
                color: "#87b4c0"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#f3f3f7"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#f3f3f7"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                fillColor: "#00000000"
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#f3f3f7"
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                joinStyle: ShapePath.MiterJoin
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                strokeStyle: ShapePath.SolidLine
                target: _vector_2_ShapePath0
            }
            PropertyChanges {
                width: 69
    
                target: help
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: help
            }
            PropertyChanges {
                target: help
                wrapMode: Text.NoWrap
            }
        }
    ]

    Rectangle {
        id: rectangle_1

        height: 70
        width: 240

        color: "#f3f3f7"
        radius: 15
    }
    Item {
        id: group

        x: 16
        y: 18

        height: 34
        width: 34

        Shape {
            id: _vector

            height: 34
            width: 34

            ShapePath {
                id: _vector_ShapePath0

                fillColor: "#00000000"
                fillRule: ShapePath.WindingFill
                strokeColor: "#000000"
                strokeWidth: 3

                PathSvg {
                    id: _vector_ShapePath0_PathSvg0

                    path: "M 17 33.99998703003919 C 19.23287156935 34.00274045835717 21.444282514642705 33.56426879628655 23.5071784918377 32.70976126879786 C 25.570074469032694 31.855253741309173 27.443794245686153 30.60155149103051 29.020689376305103 29.020689376305103 C 30.60155149103051 27.443794245686153 31.855253741309173 25.570074469032694 32.70976126879786 23.5071784918377 C 33.56426879628655 21.444282514642705 34.00274045835717 19.23287156935 33.99998703003919 17 C 34.00274045835717 14.76712843065 33.56426879628655 12.555717485357295 32.70976126879786 10.4928215081623 C 31.855253741309173 8.429925530967306 30.60155149103051 6.556204133068746 29.020689376305103 4.979309002449797 C 27.443794245686153 3.39844688772439 25.570074469032694 2.144747373296834 23.5071784918377 1.2902398458081468 C 21.444282514642705 0.43573231831945924 19.23287156935 -0.0027405406836968262 17 0.000012887634274255836 C 14.76712843065 -0.0027405406836968262 12.555717485357295 0.43573231831945924 10.4928215081623 1.2902398458081468 C 8.429925530967306 2.144747373296834 6.556204133068746 3.39844688772439 4.979309002449797 4.979309002449797 C 3.39844688772439 6.556204133068746 2.144747373296834 8.429925530967306 1.2902398458081468 10.4928215081623 C 0.43573231831945924 12.555717485357295 -0.0027405406836968262 14.76712843065 0.000012887634274255836 17 C -0.0027405406836968262 19.23287156935 0.43573231831945924 21.444282514642705 1.2902398458081468 23.5071784918377 C 2.144747373296834 25.570074469032694 3.39844688772439 27.443794245686153 4.979309002449797 29.020689376305103 C 6.556204133068746 30.60155149103051 8.429925530967306 31.855253741309173 10.4928215081623 32.70976126879786 C 12.555717485357295 33.56426879628655 14.76712843065 34.00274045835717 17 33.99998703003919 Z"
                }
            }
        }
        Shape {
            id: _vector_1

            x: 11.90
            y: 7.33

            height: 13.60
            width: 10.20

            ShapePath {
                id: _vector_1_ShapePath0

                fillColor: "#00000000"
                fillRule: ShapePath.WindingFill
                strokeColor: "#000000"
                strokeWidth: 3

                PathSvg {
                    id: _vector_1_ShapePath0_PathSvg0

                    path: "M 5.099996304512905 13.599991798400879 L 5.099996304512905 10.199994254111951 C 6.108680327986216 10.199994254111951 7.094712618023785 9.9008842989508 7.93340270249041 9.340489507626089 C 8.772092786957034 8.780094716301377 9.4257723264172 7.98358451471819 9.811778969734418 7.051682052025449 C 10.197785613051636 6.119779589332708 10.298782549742056 5.094341007979896 10.101998066385766 4.1050385628081285 C 9.905213583029477 3.1157361176363607 9.419486226948687 2.207003730910516 8.706238923036869 1.4937564253315885 C 7.992991619125052 0.7805091197526609 7.084258525228476 0.2947817752025327 6.094956082369056 0.09799729138628806 C 5.105653639509637 -0.09878719242995658 4.080214655242345 0.002209757162506931 3.148312194727788 0.38821640138195923 C 2.216409734213231 0.7742230456014115 1.4198995344917686 1.4279018519627389 0.8595047444768973 2.266591938389677 C 0.2991099544620258 3.1052820248166153 3.0198044388125003e-15 4.09131431715889 0 5.099998342989851"
                }
            }
        }
        Shape {
            id: _vector_2

            x: 14.88
            y: 24.33

            height: 4.25
            width: 4.25

            ShapePath {
                id: _vector_2_ShapePath0

                fillColor: "#000000"
                fillRule: ShapePath.OddEvenFill
                joinStyle: ShapePath.MiterJoin
                strokeColor: "#00000000"
                strokeStyle: ShapePath.SolidLine
                strokeWidth: 3

                PathSvg {
                    id: _vector_2_ShapePath0_PathSvg0

                    path: "M 2.1249983310699463 4.249996662139893 C 2.688582937356125 4.249996662139893 3.2290845603960068 4.026115182040337 3.6275990605956396 3.627600681840704 C 4.026113560795273 3.229086181641071 4.249996662139893 2.688582937356125 4.249996662139893 2.1249983310699463 C 4.249996662139893 1.5614137247837676 4.026113560795273 1.0209104804988214 3.6275990605956396 0.6223959802991885 C 3.2290845603960068 0.22388148009955555 2.688582937356125 0 2.1249983310699463 0 C 1.5614137247837676 0 1.0209121017438862 0.22388148009955555 0.6223976015442532 0.6223959802991885 C 0.2238831013446202 1.0209104804988214 0 1.5614137247837676 0 2.1249983310699463 C 0 2.688582937356125 0.2238831013446202 3.229086181641071 0.6223976015442532 3.627600681840704 C 1.0209121017438862 4.026115182040337 1.5614137247837676 4.249996662139893 2.1249983310699463 4.249996662139893 Z"
                }
            }
        }
    }
    Text {
        id: help

        x: 107
        y: 3

        height: 64
        width: 84

        color: "#000000"
        font.family: "Inknut Antiqua"
        font.pixelSize: 25
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignLeft
        text: "Help"
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignTop
        wrapMode: Text.Wrap
    }
}