import QtQuick
import QtQuick.Shapes

Rectangle {
    enum Property_1 { Property_1_Default, Property_1_Variant2, Property_1_Variant3}

    id: creditButtonwT

    property int property_2: CreditButtonwT_1.Property_1.Property_1_Default

    height: 70
    width: 240

    color: "transparent"
    opacity: 1

    states: [
        State {
            name: "Property 1=Default"
            when: creditButtonwT.property_2 === CreditButtonwT_1.Property_1.Property_1_Default
    
            PropertyChanges {
                opacity: 1
                target: creditButtonwT
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                color: "#000000"
                target: credit
            }
        },
        State {
            name: "Property 1=Variant2"
            when: creditButtonwT.property_2 === CreditButtonwT_1.Property_1.Property_1_Variant2
    
            PropertyChanges {
                opacity: 0.85
                target: creditButtonwT
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#000000"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                color: "#000000"
                target: credit
            }
        },
        State {
            name: "Property 1=Variant3"
            when: creditButtonwT.property_2 === CreditButtonwT_1.Property_1.Property_1_Variant3
    
            PropertyChanges {
                opacity: 1
                target: creditButtonwT
            }
            PropertyChanges {
                color: "#87b4c0"
                target: rectangle_1
            }
            PropertyChanges {
                strokeColor: "#f3f3f7"
                target: _vector_ShapePath0
            }
            PropertyChanges {
                strokeColor: "#f3f3f7"
                target: _vector_1_ShapePath0
            }
            PropertyChanges {
                color: "#f3f3f7"
                target: credit
            }
        }
    ]

    Rectangle {
        id: rectangle_1

        height: 70
        width: 240

        color: "#f3f3f7"
        radius: 15
    }
    Item {
        id: group

        x: 16
        y: 18

        height: 34
        width: 34

        Shape {
            id: _vector

            height: 34
            width: 34

            ShapePath {
                id: _vector_ShapePath0

                fillColor: "#00000000"
                strokeColor: "#000000"
                strokeWidth: 3

                PathSvg {
                    id: _vector_ShapePath0_PathSvg0

                    path: "M 34 17 C 34 26.388841009140016 26.388841009140016 34 17 34 C 7.611158990859986 34 0 26.388841009140016 0 17 C 0 7.611158990859986 7.611158990859986 0 17 0 C 26.388841009140016 0 34 7.611158990859986 34 17 Z"
                }
            }
        }
        Shape {
            id: _vector_1

            x: 17
            y: 10.20

            height: 13.60
            width: 0.02

            ShapePath {
                id: _vector_1_ShapePath0

                fillColor: "#00000000"
                fillRule: ShapePath.WindingFill
                strokeColor: "#000000"
                strokeWidth: 3

                PathSvg {
                    id: _vector_1_ShapePath0_PathSvg0

                    path: "M 0 13.600000381469727 L 0 6.800000190734863 M 0 0 L 0.017000388354063034 0"
                }
            }
        }
    }
    Text {
        id: credit

        x: 94
        y: 3

        height: 64
        width: 110

        color: "#000000"
        font.family: "Inknut Antiqua"
        font.pixelSize: 25
        font.weight: Font.Normal
        horizontalAlignment: Text.AlignLeft
        text: "Credit"
        textFormat: Text.PlainText
        verticalAlignment: Text.AlignTop
        wrapMode: Text.Wrap
    }
}