import QtQuick
import QtQuick.Layouts

Rectangle {
    id: sideBarRoot

    width: 275
    anchors.top: parent.top
    anchors.bottom: parent.bottom
    color: "#5986d9"

    // Properti penanda: "dashboard", "help", atau "credit"
    property string activeMenu: "dashboard"

    ColumnLayout {
        anchors.top: parent.top
        anchors.topMargin: 61
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 50

        DashboardButtonwT_1 {
            id: dashboardButton
            Layout.preferredWidth: 240
            Layout.preferredHeight: 70

            // Logika: Jika activeMenu == "dashboard", pakai Variant3 (Menyala).
            // Jika di-hover MouseArea (Tuan bisa tambah nanti), pakai Variant2.
            // Selain itu, Default.
            property_2: sideBarRoot.activeMenu === "dashboard"
                        ? DashboardButtonwT_1.Property_1.Property_1_Variant3
                        : (dashMouse.containsMouse ? DashboardButtonwT_1.Property_1.Property_1_Variant2 : DashboardButtonwT_1.Property_1.Property_1_Default)

            MouseArea {
                id: dashMouse
                anchors.fill: parent
                hoverEnabled: true
                onClicked: root.navigateTo("dashboard") // Panggil fungsi di main.qml
            }
        }

        HelpButtonwT_1 {
            id: helpButton
            Layout.preferredWidth: 240
            Layout.preferredHeight: 70

            property_2: sideBarRoot.activeMenu === "help"
                        ? HelpButtonwT_1.Property_1.Property_1_Variant3
                        : (helpMouse.containsMouse ? HelpButtonwT_1.Property_1.Property_1_Variant2 : HelpButtonwT_1.Property_1.Property_1_Default)

            MouseArea {
                id: helpMouse
                anchors.fill: parent
                hoverEnabled: true
                onClicked: root.navigateTo("help")
            }
        }

        CreditButtonwT_1 {
            id: creditButton
            Layout.preferredWidth: 240
            Layout.preferredHeight: 70

            property_2: sideBarRoot.activeMenu === "credit"
                        ? CreditButtonwT_1.Property_1.Property_1_Variant3
                        : (creditMouse.containsMouse ? CreditButtonwT_1.Property_1.Property_1_Variant2 : CreditButtonwT_1.Property_1.Property_1_Default)

            MouseArea {
                id: creditMouse
                anchors.fill: parent
                hoverEnabled: true
                onClicked: root.navigateTo("credit")
            }
        }
    }
}