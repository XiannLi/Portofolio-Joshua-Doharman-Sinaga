import QtQuick

Rectangle {
    id: currencyList
    height: 81; width: 214

    border.color: "#000000"
    border.width: 1
    color: "transparent"
    radius: 5

    signal currencySelected(string code)

    Rectangle {
        anchors.fill: parent
        anchors.margins: 1
        color: "#ffffff"
        radius: 4

        clip: true

        Column {
            anchors.fill: parent
            spacing: 0

            component CurrencyItem : Item {
                id: itm
                property string label: ""
                width: parent.width; height: 26.3

                clip: true

                opacity: mouseArea.containsMouse ? 0.8 : 1.0

                MouseArea {
                    id: mouseArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: currencyList.currencySelected(itm.label)
                }

                Rectangle {
                    anchors.fill: parent
                    color: "#15000000"
                    visible: mouseArea.containsMouse
                    z: -1
                }
            }

            CurrencyItem {
                label: "IDR"
                LIDSA { anchors.fill: parent; first: "IDR"; rectangle_22BorderColor: "transparent" }
            }
            CurrencyItem {
                label: "USD"
                LIDSA2 { anchors.fill: parent; second: "USD"; rectangle_22BorderColor: "transparent" }
            }
            CurrencyItem {
                label: "EUR"
                LIDSA3 { anchors.fill: parent; third: "EUR"; rectangle_22BorderColor: "transparent" }
            }
        }
    }
}