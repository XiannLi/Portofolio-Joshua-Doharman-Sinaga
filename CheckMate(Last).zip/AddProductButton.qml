import QtQuick
import QtQuick.Shapes

Rectangle {
    id: addProductButton

    height: 225
    width: 230

    color: "transparent"

    Image {
        id: rectangle_15

        x: -1

        source: Qt.resolvedUrl("assets/rectangle_20.png")
    }
    Shape {
        id: _vector

        x: 76.67
        y: 75

        height: 75
        width: 76.67

        ShapePath {
            id: _vector_ShapePath0

            fillColor: "#8f8f8f"
            fillRule: ShapePath.WindingFill
            joinStyle: ShapePath.MiterJoin
            strokeColor: "#00000000"
            strokeStyle: ShapePath.SolidLine
            strokeWidth: 1

            PathSvg {
                id: _vector_ShapePath0_PathSvg0

                path: "M 76.66666412353516 42.857147216796875 L 43.80952291337269 42.857147216796875 L 43.80952291337269 75 L 32.85714121016247 75 L 32.85714121016247 42.857147216796875 L 0 42.857147216796875 L 0 32.142860412597656 L 32.85714121016247 32.142860412597656 L 32.85714121016247 0 L 43.80952291337269 0 L 43.80952291337269 32.142860412597656 L 76.66666412353516 32.142860412597656 L 76.66666412353516 42.857147216796875 Z"
            }
        }
    }
}