import QtQuick
import QtQuick.Shapes
import CheckMate

Rectangle {
    id: credit

    anchors.fill: parent

    color: "#e1e5d4"

    Sidebar {
        id: side_bar
        activeMenu: "credit"
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
    }

    Item {
        id: group_21

        x: 434
        y: 10

        height: 864
        width: 826

        Shape {
            id: rectangle_17

            height: 664
            width: 826

            scale: 0.9
            transformOrigin: Item.Top

            ShapePath {
                id: rectangle_17_ShapePath0

                fillColor: "#fdfcfa"
                fillRule: ShapePath.WindingFill
                joinStyle: ShapePath.MiterJoin
                strokeColor: "#00000000"
                strokeStyle: ShapePath.SolidLine
                strokeWidth: 1

                PathSvg {
                    id: rectangle_17_ShapePath0_PathSvg0

                    path: "M 45.67967055739222 30.270096603101276 C 209.62998187969274 160.30055037262088 866.421228470087 -42.09254604037367 824.0386020375707 8.222394981650993 C 781.6559756050544 58.537336003675655 690.7956031749092 457.0285287340259 824.0386020375707 855.4576035857173 C 606.6988776011798 675.8040537623369 -158.98380437296993 955.1741404892574 33.89007636070978 830.9925240043892 C 226.76395709438947 706.810907519521 -118.27064076490828 -99.76035716641832 45.67967055739222 30.270096603101276 Z"
                }
            }
        }
        Text {
            id: header_nama

            x: 125
            y: 90

            height: 62
            width: 102

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "Nama Pembuat : "
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: orang_1

            x: 113
            y: 159

            height: 62
            width: 102

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "Muhammad Alfathi"
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: orang_2

            x: 135
            y: 247

            height: 62
            width: 104

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "Joshua Doharman"
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: orang_3

            x: 162
            y: 335

            height: 62
            width: 104

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "Surajan Sembiring"
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: orang_4

            x: 183
            y: 423

            height: 62
            width: 107

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "Aini Raisyah "
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: header_nim

            x: 590
            y: 90

            height: 62
            width: 77

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "NIM :"
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: nIM_1

            x: 570
            y: 159

            height: 62
            width: 77

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "251401055"
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: nIM_2

            x: 570
            y: 247

            height: 62
            width: 80

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "251401058"
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: nIM_3

            x: 570
            y: 335

            height: 62
            width: 79

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "251401100"
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
        Text {
            id: nIM_4

            x: 570
            y: 423

            height: 62
            width: 82

            color: "#000000"
            font.family: "Inknut Antiqua"
            font.pixelSize: 24
            font.weight: Font.Normal
            horizontalAlignment: Text.AlignLeft
            text: "251401067"
            textFormat: Text.PlainText
            verticalAlignment: Text.AlignTop
        }
    }
}